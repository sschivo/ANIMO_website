#!/usr/bin/python

import csv
import sys

f = open("Results_solo_stabili.csv", 'rt')
nomi = {}
indici = {}
daIndiceANome = {}
conta = 0
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
indiceSox9 = 0
for row in reader:
	if skippa:
		for i in range(len(row)):
			if (row[i].strip() == "Sox9"):
				indiceSox9 = i
				break
		skippa = False
		continue
	if (not(row[0].strip() in nomi)):
		nomi[row[0].strip()] = row[1].strip()
		indici[row[0].strip()] = conta
		daIndiceANome[conta] = row[0].strip()
		conta = conta + 1
	if (not(row[3].strip() in nomi)):
		nomi[row[3].strip()] = row[4].strip()
		indici[row[3].strip()] = conta
		daIndiceANome[conta] = row[3].strip()
		conta = conta + 1

matrice = [[[[0 for x in xrange(2)] for x in xrange(2)] for x in xrange(conta)] for x in xrange(conta)]
f = open("Results_solo_stabili.csv", 'rt')
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
for row in reader:
	if skippa:
		skippa = False
		continue
	init1 = int(row[2].strip())
	init2 = int(row[5].strip())
	if (init1 == 100):
		init1 = 1
	if (init2 == 100):
		init2 = 1
	matrice[indici[row[0].strip()]][indici[row[3].strip()]][init1][init2] = int(row[indiceSox9].strip())
	matrice[indici[row[3].strip()]][indici[row[0].strip()]][init2][init1] = int(row[indiceSox9].strip())

for i in range(len(matrice[0])):
	sys.stdout.write("," + nomi[daIndiceANome[i]] + " (0)," + nomi[daIndiceANome[i]] + " (100)")
print ""
for i in range(len(matrice)):
	sys.stdout.write(nomi[daIndiceANome[i]] + " (0)")
	for j in range(len(matrice[0])):
		if (j < i):
			sys.stdout.write("," + str(matrice[i][j][0][0]) + "," + str(matrice[i][j][0][1]))
		else:
			sys.stdout.write(",,")
	sys.stdout.write("\n")
	sys.stdout.write(nomi[daIndiceANome[i]] + " (100)")
	for j in range(len(matrice[0])):
		if (j < i):
			sys.stdout.write("," + str(matrice[i][j][1][0]) + "," + str(matrice[i][j][1][1]))
		else:
			sys.stdout.write(",,")
	sys.stdout.write("\n")
'''mezzo = len(matrice) / 2
for i in range(mezzo):
	print nomi[daIndiceANome[i]] + " (0)",
	for j in range(len(matrice[0])):
		if (j >= mezzo):
			print "," + str(matrice[i][j][0][0]) + "," + str(matrice[i][j][0][1]),
		else:
			print ",,",
	print ""
	print nomi[daIndiceANome[i]] + " (100)",
	for j in range(len(matrice[0])):
		if (j >= mezzo):
			print "," + str(matrice[i][j][1][0]) + "," + str(matrice[i][j][1][1]),
		else:
			print ",,",
	print ""'''
