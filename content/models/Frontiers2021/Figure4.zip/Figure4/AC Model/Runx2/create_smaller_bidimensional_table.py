#!/usr/bin/python

import csv
import sys

f = open("Results_solo_stabili.csv", 'rt')
nomi = {}
indici = {}
daIndiceANome = {}
conta = 0
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
indiceSox9 = 0
indiceMatrixSox9 = 0
indiceMatrixSox9PTM = 0
for row in reader:
	if skippa:
		for i in range(len(row)):
			if (row[i].strip() == "Sox9"):
				indiceSox9 = i
		skippa = False
		continue
	if (not(row[0].strip() in nomi)):
		nomi[row[0].strip()] = row[1].strip()
		if (row[1].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[1].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[0].strip()] = conta
		daIndiceANome[conta] = row[0].strip()
		conta = conta + 1
	if (not(row[3].strip() in nomi)):
		nomi[row[3].strip()] = row[4].strip()
		if (row[4].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[4].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[3].strip()] = conta
		daIndiceANome[conta] = row[3].strip()
		conta = conta + 1

matrice = [[[[0 for x in xrange(2)] for x in xrange(2)] for x in xrange(conta)] for x in xrange(conta)]
f = open("Results_solo_stabili.csv", 'rt')
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
for row in reader:
	if skippa:
		skippa = False
		continue
	init1 = int(row[2].strip())
	init2 = int(row[5].strip())
	if (init1 == 100):
		init1 = 1
	if (init2 == 100):
		init2 = 1
	matrice[indici[row[0].strip()]][indici[row[3].strip()]][init1][init2] = int(row[indiceSox9].strip())
	matrice[indici[row[3].strip()]][indici[row[0].strip()]][init2][init1] = int(row[indiceSox9].strip())

stampa = [[0 for x in xrange(2)] for x in xrange(conta)]
for i in range(len(stampa)):
	for v in range(2):
		stampa[i][v] = True
stampa[indiceMatrixSox9][1] = False
stampa[indiceMatrixSox9PTM][1] = False
for i in range(len(matrice)):
	rifai = False
	for v in range(2):
		if (not stampa[i][v]):
			continue
		stampa[i][v] = False
		primoValore = matrice[i][0][v][v]
		rifai = True
		for j in range(len(matrice[0])):
			if (not stampa[j][v]):
				continue
			if (matrice[i][j][v][v] != primoValore):
				stampa[i][v] = True
				rifai = False
				break
	if (rifai):
		i = 0

for i in range(len(matrice[0])):
	if (stampa[i][0]):
		sys.stdout.write("," + nomi[daIndiceANome[i]] + " (0)")
	if (stampa[i][1]):
		sys.stdout.write("," + nomi[daIndiceANome[i]] + " (100)")
print ""

for i in range(len(matrice)):
	if (stampa[i][0]):
		sys.stdout.write(nomi[daIndiceANome[i]] + " (0)")
		for j in range(len(matrice[0])):
			if (j < i):
				if (stampa[j][0]):
					sys.stdout.write("," + str(matrice[i][j][0][0]))
				if (stampa[j][1]):
					sys.stdout.write("," + str(matrice[i][j][0][1]))
			else:
				sys.stdout.write(",,")
		sys.stdout.write("\n")
	if (stampa[i][1]):
		sys.stdout.write(nomi[daIndiceANome[i]] + " (100)")
		for j in range(len(matrice[0])):
			if (j < i):
				if (stampa[j][0]):
					sys.stdout.write("," + str(matrice[i][j][1][0]))
				if (stampa[j][1]):
					sys.stdout.write("," + str(matrice[i][j][1][1]))
			else:
				sys.stdout.write(",,")
		sys.stdout.write("\n")
