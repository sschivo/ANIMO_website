#!/usr/bin/python

import csv
import sys
import math
import os

RUNX2_STATE = "R"
SOX9_STATE = "S"
NULL_STATE = "N"
OTHER_STATE = "O"
UNSTABLE_STATE = "@"
INITIAL_STATE = NULL_STATE

currentDir = os.path.dirname(os.path.realpath("."))
path, dirName = os.path.split(currentDir)
#sys.stderr.write("Current directory: " + dirName)
if (dirName == "Runx2"):
	INITIAL_STATE = RUNX2_STATE
elif (dirName == "Sox9"):
	INITIAL_STATE = SOX9_STATE
#sys.stderr.write("\nInitial state: " + INITIAL_STATE + "\n")

f = open("Results.csv", 'rt')
nomi = {}
indici = {}
daIndiceANome = {}
daFullNameAIndice = {}
conta = 0
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
indiceStable = 0
indiceSox9 = 0
indiceRunx2 = 0
indiceMatrixSox9 = 0
indiceMatrixSox9PTM = 0
for row in reader:
	if skippa:
		for i in range(len(row)):
			if (row[i].strip() == "Stable"):
				indiceStable = i
			elif (row[i].strip() == "Runx2"):
				indiceRunx2 = i
			elif (row[i].strip() == "Sox9"):
				indiceSox9 = i
		skippa = False
		continue
	if (not(row[0].strip() in nomi)):
		nomi[row[0].strip()] = row[1].strip()
		if (row[1].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[1].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[0].strip()] = conta
		daIndiceANome[conta] = row[0].strip()
		daFullNameAIndice[row[1].strip()] = conta
		conta = conta + 1
	if (not(row[3].strip() in nomi)):
		nomi[row[3].strip()] = row[4].strip()
		if (row[4].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[4].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[3].strip()] = conta
		daIndiceANome[conta] = row[3].strip()
		daFullNameAIndice[row[4].strip()] = conta
		conta = conta + 1

matrice = [[[[0 for x in xrange(2)] for x in xrange(2)] for x in xrange(conta)] for x in xrange(conta)]
for i in range(len(matrice)):
	for j in range(len(matrice[0])):
		for v1 in range(2):
			for v2 in range(2):
				matrice[i][j][v1][v2] = 0
f = open("Results.csv", 'rt')
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
for row in reader:
	if skippa:
		skippa = False
		continue
	init1 = int(row[2].strip())
	init2 = int(row[5].strip())
	if (init1 == 100):
		init1 = 1
	if (init2 == 100):
		init2 = 1
	stable = False
	if (row[indiceStable].strip() == "TRUE"):
		stable = True
	valSox9 = int(row[indiceSox9].strip())
	valRunx2 = int(row[indiceRunx2].strip())
	val = ""
	if (valSox9 > 60 and valRunx2 < 30):
		val = SOX9_STATE
	elif (valSox9 < 30 and valRunx2 > 60):
		val = RUNX2_STATE
	elif (valSox9 < 30 and valRunx2 < 30):
		val = NULL_STATE
	else:
		val = OTHER_STATE + "(" + str(valSox9) + ", " + str(valRunx2) + ")"
	if (not stable):
		val = val + UNSTABLE_STATE
	matrice[indici[row[0].strip()]][indici[row[3].strip()]][init1][init2] = val
	matrice[indici[row[3].strip()]][indici[row[0].strip()]][init2][init1] = val

stampa = [[0 for x in xrange(2)] for x in xrange(conta)]
for i in range(len(stampa)):
	for v in range(2):
		stampa[i][v] = True
stampa[indiceMatrixSox9][1] = False
stampa[indiceMatrixSox9PTM][1] = False
for i in range(len(matrice)):
	rifai = False
	for v in range(2):
		if (not stampa[i][v]):
			continue
		stampa[i][v] = False
		primoValore = matrice[i][0][v][v]
		rifai = True
		for j in range(len(matrice[0])):
			if (not stampa[j][v]):
				continue
			if (matrice[i][j][v][v] != primoValore):
				stampa[i][v] = True
				rifai = False
				break
		if (stampa[i][v]):
			stampa[i][v] = False
			for j in range(len(matrice[0])):
				if (not stampa[j][v]):
					continue
				if (matrice[i][j][v][v] == 1 or matrice[i][j][v][v] == -1):
					stampa[i][v] = True
					break
	if (rifai):
		i = 0

'''
for i in range(len(matrice[0])):
	if (stampa[i][0]):
		sys.stdout.write("," + nomi[daIndiceANome[i]] + " (0)")
	if (stampa[i][1]):
		sys.stdout.write("," + nomi[daIndiceANome[i]] + " (100)")
print ""

for i in range(len(matrice)):
	if (stampa[i][0]):
		sys.stdout.write(nomi[daIndiceANome[i]] + " (0)")
		for j in range(len(matrice[0])):
			if (j < i):
				if (stampa[j][0]):
					sys.stdout.write("," + str(matrice[i][j][0][0]))
				if (stampa[j][1]):
					sys.stdout.write("," + str(matrice[i][j][0][1]))
			else:
				sys.stdout.write(",,")
		sys.stdout.write("\n")
	if (stampa[i][1]):
		sys.stdout.write(nomi[daIndiceANome[i]] + " (100)")
		for j in range(len(matrice[0])):
			if (j < i):
				if (stampa[j][0]):
					sys.stdout.write("," + str(matrice[i][j][1][0]))
				if (stampa[j][1]):
					sys.stdout.write("," + str(matrice[i][j][1][1]))
			else:
				sys.stdout.write(",,")
		sys.stdout.write("\n")
'''










#Names of the possible groups identifying pathways. Note that we use two distinct groups for the "ON" and "OFF" state of the same pathway
groupNames = ["Wnt Signaling ON", "Wnt Signaling OFF", "BMP/TGFb Signaling ON", "BMP/TGFb Signaling OFF", "FGF Signaling, RTK ON", "FGF Signaling, RTK OFF", "Other signaling", "Transcription factors", "Other"]

# Coordinates: index of pathway (same sequence as in groupNames),
#			   position inside that pathway group
# Those two coordinates lead to an array that contains node name and value (0/100 for KO/Overactivation) in that particular pathway group
ordering = [
	[#   Node, Init, Has this configuration any result (i.e., is there at least one combination with some other configuration that leads to a change of state - so from Runx2 to Sox9 if we are in Runx2 initial state)?
		["Wnt", 100, False],
		["FRZB", 0, False],
		["Frizzled - LRP 5/6", 100, False],
		["DKK1", 0, False],
		["Dsh", 100, False],
		["destruction complex", 0, False],
		["B-catenin", 100, False],
		["Lef/Tcf", 100, False],
		["Bcatleftcfcomplex", 100, False]
	],

	[
		["Wnt", 0, False],
		["FRZB", 100, False],
		["Frizzled - LRP 5/6", 0, False],
		["DKK1", 100, False],
		["Dsh", 0, False],
		["destruction complex", 100, False],
		["B-catenin", 0, False],
		["Lef/Tcf", 0, False],
		["Bcatleftcfcomplex", 0, False]
	],

	[
		["BMP", 100, False],
		["GREM1", 0, False],
		["p38", 100, False],
		["R-smad", 100, False],
		["Smadcomplex", 100, False],
		["Smad7", 0, False],
		["TGFb", 100, False],
		["Smad3", 100, False]
	],

	[
		["BMP", 0, False],
		["GREM1", 100, False],
		["p38", 0, False],
		["R-smad", 0, False],
		["Smadcomplex", 0, False],
		["Smad7", 100, False],
		["TGFb", 0, False],
		["Smad3", 0, False]
	],

	[
		["FGF", 100, False],
		["FGFR1", 100, False],
		["FGFR3", 100, False],
		["IGF-1", 100, False],
		["IGF-1R", 100, False],
		["Ras", 100, False],
		["ERK1/2", 100, False],
		["PI3K", 100, False],
		["Akt", 100, False]
	],

	[
		["FGF", 0, False],
		["FGFR1", 0, False],
		["FGFR3", 0, False],
		["IGF-1", 0, False],
		["IGF-1R", 0, False],
		["Ras", 0, False],
		["ERK1/2", 0, False],
		["PI3K", 0, False],
		["Akt", 0, False]
	],

	[
		["PKA", 0, False],
		["PKA", 100, False],
		["PP2A", 0, False],
		["PP2A", 100, False],
		["PTHrP", 0, False],
		["PTHrP", 100, False],
		["PPR", 0, False],
		["PPR", 100, False],
		["Ihh", 0, False],
		["Ihh", 100, False],
		["GSK", 0, False],
		["GSK", 100, False]
	],

	[
		["Runx2", 0, False],
		["Runx2", 100, False],
		["Sox9", 0, False],
		["Sox9", 100, False],
		["Msx2", 0, False],
		["Msx2", 100, False],
		["Dlx5", 0, False],
		["Dlx5", 100, False],
		["Gli2", 0, False],
		["Gli2", 100, False],
		["ATF2", 0, False],
		["ATF2", 100, False],
		["CCND1", 0, False],
		["CCND1", 100, False],
		["Ets1", 0, False],
		["Ets1", 100, False],
		["ATF4", 0, False],
		["ATF4", 100, False],
		["HIF-2a", 0, False],
		["HIF-2a", 100, False],
		["MEF2C", 0, False],
		["MEF2C", 100, False],
		["NFkb", 0, False],
		["NFkb", 100, False],
		["Nkx3.2", 0, False],
		["Nkx3.2", 100, False],
		["STAT1", 0, False],
		["STAT1", 100, False]
	],

	[
		["HDAC4", 0, False],
		["HDAC4", 100, False],
		["dEF-1", 0, False],
		["dEF-1", 100, False]
	]
]


#First table: all the data we have. While printing it, see if some data has less importance (i.e. we can avoid it in the second table)
sys.stdout.write(";;") #First two columns not used in the first line
for i in range(len(ordering)):
	sys.stdout.write(groupNames[i])
	for col in range(len(ordering[i])):
		exists = False
		try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[ordering[i][col][0]]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (exists):
			sys.stdout.write(";")
	sys.stdout.write(";") #Add empty column after each pathway group
sys.stdout.write("\n")
sys.stdout.write("Group Name;Node (fixed)")
for i in range(len(ordering)):
	for col in range(len(ordering[i])):
		exists = False
		try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[ordering[i][col][0]]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (exists):
			sys.stdout.write(";" + ordering[i][col][0] + "(" + str(ordering[i][col][1]) + ")")
	sys.stdout.write(";") #Add empty column after each pathway group
sys.stdout.write("\n")
for pathway in range(len(ordering)):
	sys.stdout.write(groupNames[pathway])
	for setting in range(len(ordering[pathway])):
		reactant1 = ordering[pathway][setting][0]
		exists = False
		try: #Check that both reactants exist in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[reactant1]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (not exists):
			continue
		fixed1 = ordering[pathway][setting][1]
		if (fixed1 == 100):
			fixed1 = 1
		sys.stdout.write(";" + reactant1 + " (" + str(100 * fixed1) + ")")
		for pathway2 in range(len(ordering)):
			for setting2 in range(len(ordering[pathway2])):
				reactant2 = ordering[pathway2][setting2][0]
				fixed2 = ordering[pathway2][setting2][1]
				if (fixed2 == 100):
					fixed2 = 1
				exists = False
				try: #Check that both reactants exist in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
					daFullNameAIndice[reactant1]
					daFullNameAIndice[reactant2]
					exists = True
				except IndexError:
					exists = False
				except KeyError:
					exists = False
				if (exists):
					if (pathway < len(ordering) - 2 and pathway2 < len(ordering) - 2 and matrice[daFullNameAIndice[reactant1]][daFullNameAIndice[reactant2]][fixed1][fixed2] != 0 and matrice[daFullNameAIndice[reactant1]][daFullNameAIndice[reactant2]][fixed1][fixed2] != INITIAL_STATE and matrice[daFullNameAIndice[reactant1]][daFullNameAIndice[reactant2]][fixed1][fixed2] != NULL_STATE):
						ordering[pathway][setting][2] = ordering[pathway2][setting2][2] = True
					sys.stdout.write(";" + str(matrice[daFullNameAIndice[reactant1]][daFullNameAIndice[reactant2]][fixed1][fixed2]))
			sys.stdout.write(";") #Empty column after each pathway group
		sys.stdout.write("\n")
	#sys.stdout.write("\n") #Empty line after each pathway group
	for setting in range(len(ordering[pathway])):
		sys.stdout.write(";")
	sys.stdout.write("\n")


#Second table: "zoomed in" version, with only those in the 'signaling' part that have an effect (i.e. ordering[pathway][setting][2] is True)
sys.stdout.write("\n\n;;") #First two columns not used in the first line
for i in range(len(ordering) - 2):
	onePresent = False
	for col in range(len(ordering[i])):
		exists = False
		try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[ordering[i][col][0]]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (exists and ordering[i][col][2]): #We print the name of the group only if at least one of the configurations is worthy of being printed
			onePresent = True
			break
	if (onePresent):
		sys.stdout.write(groupNames[i])
		for col in range(len(ordering[i])):
			exists = False
			try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
				daFullNameAIndice[ordering[i][col][0]]
				exists = True
			except IndexError:
				exists = False
			except KeyError:
				exists = False
			if (exists and ordering[i][col][2]):
				sys.stdout.write(";")
		sys.stdout.write(";") #Add empty column after each pathway group
sys.stdout.write("\n")
sys.stdout.write("Group Name;Node (fixed)")
for i in range(len(ordering)):
	printedSomething = False
	for col in range(len(ordering[i])):
		exists = False
		try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[ordering[i][col][0]]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (exists and ordering[i][col][2]):
			sys.stdout.write(";" + ordering[i][col][0] + "(" + str(ordering[i][col][1]) + ")")
			printedSomething = True
	if (printedSomething):
		sys.stdout.write(";") #Add empty column after each pathway group
sys.stdout.write("\n")
for pathway in range(len(ordering) - 2):
	onePresent = False
	for setting in range(len(ordering[pathway])):
		exists = False
		try: #Check that a reactant exists in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
			daFullNameAIndice[ordering[pathway][setting][0]]
			exists = True
		except IndexError:
			exists = False
		except KeyError:
			exists = False
		if (exists and ordering[pathway][setting][2]): #We print the name of the group only if at least one of the configurations is worthy of being printed
			onePresent = True
			break
	if (onePresent):
		sys.stdout.write(groupNames[pathway])
		for setting in range(len(ordering[pathway])):
			reactant1 = ordering[pathway][setting][0]
			exists = False
			try: #Check that both reactants exist in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
				daFullNameAIndice[reactant1]
				exists = True
			except IndexError:
				exists = False
			except KeyError:
				exists = False
			if (not exists or not ordering[pathway][setting][2]):
				continue
			fixed1 = ordering[pathway][setting][1]
			if (fixed1 == 100):
				fixed1 = 1
			sys.stdout.write(";" + reactant1 + " (" + str(100 * fixed1) + ")")
			for pathway2 in range(len(ordering) - 2):
				printedSomething = False
				for setting2 in range(len(ordering[pathway2])):
					reactant2 = ordering[pathway2][setting2][0]
					fixed2 = ordering[pathway2][setting2][1]
					if (fixed2 == 100):
						fixed2 = 1
					exists = False
					try: #Check that both reactants exist in the current model (e.g. DKK1, GREM1, FRZB don't exist in models 1 and 3)
						daFullNameAIndice[reactant1]
						daFullNameAIndice[reactant2]
						exists = True
					except IndexError:
						exists = False
					except KeyError:
						exists = False
					if (exists and ordering[pathway2][setting2][2]):
						sys.stdout.write(";" + str(matrice[daFullNameAIndice[reactant1]][daFullNameAIndice[reactant2]][fixed1][fixed2]))
						printedSomething = True
				if (printedSomething):
					sys.stdout.write(";") #Empty column after each pathway group
			sys.stdout.write("\n")
		#sys.stdout.write("\n") #Empty line after each pathway group
		for setting in range(len(ordering[pathway])):
			sys.stdout.write(";")
		sys.stdout.write("\n")

'''
#Reference to pathway group (pathway) and row inside that group (setting) from node name and modification (0 / 100)
namesLocation = {}
for pathway in range(len(ordering)):
	for setting in range(len(ordering[pathway])):
		namesLocation[(ordering[pathway][setting][0], ordering[pathway][setting][1])] = (pathway, setting)


for m in range(4):
	(percSox9NoChanges, confSox9NoChanges) = percentages[m][Sox9] #Get the original percentage of Sox9 in the model without any change
	(percRunx2NoChanges, confRunx2NoChanges) = percentages[m][Runx2]
	minSox9 = minRunx2 = -math.log(2, 10) # Find the min/max values on the weighted scale for Sox9 and Runx2 (the one corresponding to 0%)
	maxSox9 = math.log(1 + (100 - percSox9NoChanges) / percSox9NoChanges, 10) # Maximum corresponds to 100% Sox9 or Runx2
	maxRunx2 = math.log(1 + (100 - percRunx2NoChanges) / percRunx2NoChanges, 10)
	for change in range(2): # 0 = KO, 100 = Overactivation (100)
		skippa = True
		for row in rOneChange[m][change]:
			if (skippa): #The first row of the .csv file is the header, which does not contain useful data
				skippa = False
				continue
			exists = False
			modification = 0
			if (change == 1):
				modification = 100
			try: #Not all nodes/values combinations are listed in the groups
				namesLocation[(row[0], modification)]
				exists = True
			except IndexError:
				exists = False
			except KeyError:
				exists = False
			if (exists):
				(pathway, setting) = namesLocation[(row[0], modification)] #Look for the position in the ordered table of the currently found node name + change (KO/Overact.)
				percSox9 = float(row[1]) #Read the Sox9 percentage (and 0.99 conf. interval) caused by the current modification (KO/Overact., = change) to the current node ( = row[0])
				confSox9 = float(row[2])
				effectSox9 = 0 #Determine the effect on Sox9 with a number representing the difference, if statistically significant (i.e., consider 0.99 conf. values)
				if (percSox9 - confSox9 > percSox9NoChanges + confSox9NoChanges or percSox9 + confSox9 < percSox9NoChanges - confSox9NoChanges):
					diff = (percSox9 - percSox9NoChanges) / percSox9NoChanges
					mult = 1
					if (diff < 0):
						mult = -1
						diff = -diff
					effectSox9 = mult * math.log(1 + diff, 10) #Measure of "how much" influence has this particular KO/Overactivation on the percentage of Sox9
					if (effectSox9 < 0):
						effectSox9 = -effectSox9 / minSox9
					else:
						effectSox9 = effectSox9 / maxSox9
				ordering[pathway][setting][2*(1+m)] = effectSox9
				#Do the same with Runx2
				percRunx2 = float(row[3])
				confRunx2 = float(row[4])
				effectRunx2 = 0
				if (percRunx2 - confRunx2 > percRunx2NoChanges + confRunx2NoChanges or percRunx2 + confRunx2 < percRunx2NoChanges - confRunx2NoChanges):
					diff = (percRunx2 - percRunx2NoChanges) / percRunx2NoChanges
					mult = 1
					if (diff < 0):
						mult = -1
						diff = -diff
					effectRunx2 = mult * math.log(1 + diff, 10)
					if (effectRunx2 < 0):
						effectRunx2 = -effectRunx2 / minRunx2
					else:
						effectRunx2 = effectRunx2 / maxRunx2
				ordering[pathway][setting][2*(1+m)+1] = effectRunx2


print ";;;Model 1;;Model 2;;Model3;;Model4;"
print "Group Name;Node Name;Node Value;Effect on Sox9;Effect on Runx2;Effect on Sox9;Effect on Runx2;Effect on Sox9;Effect on Runx2;Effect on Sox9;Effect on Runx2"
for pathway in range(len(ordering)):
	sys.stdout.write(groupNames[pathway])
	for setting in range(len(ordering[pathway])):
		for k in range(10): #Output all effects together, one after the other (and thus fill the row in the table)
			sys.stdout.write(";")
			if (not ordering[pathway][setting][k] is None): #Those values that still have 'None' were not computed, so we should output nothing
				sys.stdout.write(str(ordering[pathway][setting][k]))
		sys.stdout.write("\n")
	sys.stdout.write("\n")
'''
