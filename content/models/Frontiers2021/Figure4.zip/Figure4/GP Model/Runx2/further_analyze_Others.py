#!/usr/bin/python

import csv
import sys
import math
import os


RUNX2_STATE = "R"
SOX9_STATE = "S"
NULL_STATE = "N"
OTHER_STATE = "O"
UNSTABLE_STATE = "@"

reactantIDs = {}
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

#Allow to look for the index (in reactantIDs[]) of given reactant ID
reactantIDXs = {}
for idx, val in enumerate(reactantIDs):
	reactantIDXs[reactantIDs[val]] = val

f = open("Results.csv", 'rt')
nomi = {}
indici = {}
daIndiceANome = {}
daFullNameAIndice = {}
conta = 0
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
indiceStable = 0
indiceSox9 = 0
indiceRunx2 = 0
indiceMatrixSox9 = 0
indiceMatrixSox9PTM = 0
for row in reader:
	if skippa:
		for i in range(len(row)):
			if (row[i].strip() == "Stable"):
				indiceStable = i
			elif (row[i].strip() == "Runx2"):
				indiceRunx2 = i
			elif (row[i].strip() == "Sox9"):
				indiceSox9 = i
		skippa = False
		continue
	if (not(row[0].strip() in nomi)):
		nomi[row[0].strip()] = row[1].strip()
		if (row[1].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[1].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[0].strip()] = conta
		daIndiceANome[conta] = row[0].strip()
		daFullNameAIndice[row[1].strip()] = conta
		conta = conta + 1
	if (not(row[3].strip() in nomi)):
		nomi[row[3].strip()] = row[4].strip()
		if (row[4].strip() == "Sox9"):
			indiceMatrixSox9 = conta
		if (row[4].strip() == "Sox9 PTM"):
			indiceMatrixSox9PTM = conta
		indici[row[3].strip()] = conta
		daIndiceANome[conta] = row[3].strip()
		daFullNameAIndice[row[4].strip()] = conta
		conta = conta + 1

f = open("Results.csv", 'rt')
fout = open("Results_noOthers.csv", "w+b")
reader = csv.reader(f,delimiter=",", quotechar='"')
skippa = True
rigaIntestazione = {}
StableIDX = Sox9IDX = Runx2IDX = firstFinalIDX = lastFinalIDX = numberOfFinals = 0
for row in reader:
	if (skippa): # First row: header. Get the names of the nodes
		conta = 0
		rigaIntestazione = row
		for i in row:
			if (i.strip() != ""):
				fout.write(i.strip() + ",")
			if (i.strip() == "Stable"):
				StableIDX = conta
			if (i.strip() == "Sox9"):
				Sox9IDX = conta
			if (i.strip() == "Runx2"):
				Runx2IDX = conta
			conta += 1
		fout.write("\n")
		firstFinalIDX = StableIDX + 1
		lastFinalIDX = conta - 1
		numberOfFinals = lastFinalIDX - firstFinalIDX + 1
		#sys.stderr.write("N. of finals: " + str(numberOfFinals) + "\n")
		skippa = False
		continue
	init1 = int(row[2].strip())
	init2 = int(row[5].strip())
	#stable = False
	#if (row[indiceStable].strip() == "TRUE"):
    #	stable = True
	
	valSox9 = int(row[indiceSox9].strip())
	valRunx2 = int(row[indiceRunx2].strip())
	
	#sys.stderr.write("Sox9 = " + str(valSox9) + ", Runx2 = " + str(valRunx2) + "\n")
	
	# Either Runx2, Sox9 or Null state: just copy the row as it is
	if (valSox9 > 60 and valRunx2 < 30 or valSox9 < 30 and valRunx2 > 60 or valSox9 < 30 and valRunx2 < 30):
		for k in row:
			if (k.strip() != ""):
				fout.write(k.strip() + ",")
				#sys.stderr.write("** " + k.strip() + ",\n")
		fout.write("\n")
	# 'Other' state: finish the simulation without keeping reactants fixed
	else:
		sys.stderr.write(row[2].strip() + " " + row[1].strip() + " + " + row[5].strip() + " " + row[4].strip() + " = 'Other'...")
		fE = open("execute_one_sim.sh", "w+b")
		fE.write("#!/bin/bash\n")
		fE.write("declare -A reactantVals\n")
		for j in range(numberOfFinals):
			nome = rigaIntestazione[firstFinalIDX + j].strip()
			if (nome == ""):
				continue
			#sys.stderr.write("'" + nome + "'\n");
			fE.write('reactantVals[' + str(reactantIDXs[nome]) + ']=\"' + row[firstFinalIDX + j].strip() + '\"\n')
		fE.close()
		os.system("cat execute_one_sim_template.sh >> execute_one_sim.sh")
		os.system("bash execute_one_sim.sh")
		os.system("rm execute_one_sim.sh")
		#Parse the result and identify it as one of the final states, transfering the number of 'other' to that final state
		fO = open("ANIMO_output_tmp.csv", 'rt')
		readerO = csv.reader(fO,delimiter=",", quotechar='"')
		for rowO in readerO: #Should be only one row
			if (rowO[StableIDX-StableIDX].strip() == "TRUE"):
				#We are relabeling the simulations currently known as "other" as one of the
				#"real" final states (sox9, runx2, null)
				if (int(rowO[Sox9IDX-StableIDX].strip()) > 60 and int(rowO[Runx2IDX-StableIDX].strip()) < 30):
					othersClassifiedAs = "Sox9"
				elif (int(rowO[Sox9IDX-StableIDX].strip()) < 30 and int(rowO[Runx2IDX-StableIDX].strip()) > 60):
					othersClassifiedAs = "Runx2"
				elif (int(rowO[Sox9IDX-StableIDX].strip()) < 30 and int(rowO[Runx2IDX-StableIDX].strip()) < 30):
					othersClassifiedAs = "Null"
				else:
					othersClassifiedAs = "(Could not identify)"
					sys.stderr.write("Others=" + str(others))
			for k in range(6): # Initialization of the current row is copied directly
				fout.write(row[k].strip() + ",")
			for k in rowO:
				if (k.strip() != ""):
					fout.write(k.strip() + ",") # Write the rest of the result
				#sys.stderr.write(k.strip() + "\n")
			fout.write("\n")
		fO.close()
		os.system("rm ANIMO_output_tmp.csv")
		sys.stderr.write("\b\b\b --> " + othersClassifiedAs + "\n")
		
fout.close()
