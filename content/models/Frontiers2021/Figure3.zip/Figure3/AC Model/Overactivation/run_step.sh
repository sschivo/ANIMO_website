#!/bin/bash
#Execute the given number of simulations (second parameter) and label the results with the given index (first parameter)
#Replace the content of PATH_TO_VERIFYTA with the path to the "verifyta" executable of UPPAAL
PATH_TO_VERIFYTA=/home/schivos/uppaal/bin-Linux/verifyta
R=$1
declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

declare -A reactantVals
reactantVals[9]="100"
reactantVals[14]="100"
reactantVals[20]="100"
reactantVals[21]="100"
reactantVals[43]="100"
reactantVals[54]="100"
reactantVals[62]="100"

declare -A usedProcesses
usedProcesses[0]="Reactant_R0(R0, 100);"
usedProcesses[1]="Reactant_R1(R1, 100);"
usedProcesses[2]="Reactant_R2(R2, 100);"
usedProcesses[3]="Reactant_R3(R3, 100);"
usedProcesses[4]="Reactant_R4(R4, 100);"
usedProcesses[5]="Reactant_R5(R5, 100);"
usedProcesses[6]="Reactant_R6(R6, 100);"
usedProcesses[7]="Reactant_R7(R7, 100);"
usedProcesses[8]="Reactant_R8(R8, 100);"
usedProcesses[10]="Reactant_R10(R10, 100);"
usedProcesses[11]="Reactant_R11(R11, 100);"
usedProcesses[12]="Reactant_R12(R12, 100);"
usedProcesses[13]="Reactant_R13(R13, 100);"
usedProcesses[15]="Reactant_R15(R15, 100);"
usedProcesses[16]="Reactant_R16(R16, 100);"
usedProcesses[17]="Reactant_R17(R17, 100);"
usedProcesses[18]="Reactant_R18(R18, 100);"
usedProcesses[19]="Reactant_R19(R19, 100);"
usedProcesses[22]="Reactant_R22(R22, 100);"
usedProcesses[23]="Reactant_R23(R23, 100);"
usedProcesses[24]="Reactant_R24(R24, 100);"
usedProcesses[25]="Reactant_R25(R25, 100);"
usedProcesses[26]="Reactant_R26(R26, 100);"
usedProcesses[27]="Reactant_R27(R27, 100);"
usedProcesses[28]="Reactant_R28(R28, 100);"
usedProcesses[29]="Reactant_R29(R29, 100);"
usedProcesses[30]="Reactant_R30(R30, 100);"
usedProcesses[31]="Reactant_R31(R31, 100);"
usedProcesses[32]="Reactant_R32(R32, 100);"
usedProcesses[33]="Reactant_R33(R33, 100);"
usedProcesses[34]="Reactant_R34(R34, 100);"
usedProcesses[35]="Reactant_R35(R35, 100);"
usedProcesses[36]="Reactant_R36(R36, 100);"
usedProcesses[37]="Reactant_R37(R37, 100);"
usedProcesses[38]="Reactant_R38(R38, 100);"
usedProcesses[39]="Reactant_R39(R39, 100);"
usedProcesses[40]="Reactant_R40(R40, 100);"
usedProcesses[41]="Reactant_R41(R41, 100);"
usedProcesses[42]="Reactant_R42(R42, 100);"
usedProcesses[44]="Reactant_R44(R44, 100);"
usedProcesses[45]="Reactant_R45(R45, 100);"
usedProcesses[46]="Reactant_R46(R46, 100);"
usedProcesses[47]="Reactant_R47(R47, 100);"
usedProcesses[48]="Reactant_R48(R48, 100);"
usedProcesses[49]="Reactant_R49(R49, 100);"
usedProcesses[50]="Reactant_R50(R50, 100);"
usedProcesses[51]="Reactant_R51(R51, 100);"
usedProcesses[52]="Reactant_R52(R52, 100);"
usedProcesses[53]="Reactant_R53(R53, 100);"
usedProcesses[55]="Reactant_R55(R55, 100);"
usedProcesses[56]="Reactant_R56(R56, 100);"
usedProcesses[57]="Reactant_R57(R57, 100);"
usedProcesses[58]="Reactant_R58(R58, 100);"
usedProcesses[59]="Reactant_R59(R59, 100);"
usedProcesses[60]="Reactant_R60(R60, 100);"
usedProcesses[61]="Reactant_R61(R61, 100);"
usedProcesses[63]="Reactant_R63(R63, 100);"
usedProcesses[64]="Reactant_R64(R64, 100);"
usedProcesses[65]="Reactant_R65(R65, 100);"
usedProcesses[66]="Reactant_R66(R66, 100);"
usedProcesses[67]="Reactant_R67(R67, 100);"
usedProcesses[68]="Reactant_R68(R68, 100);"
usedProcesses[69]="Reactant_R69(R69, 100);"
usedProcesses[70]="Reactant_R70(R70, 100);"
usedProcesses[71]="Reactant_R71(R71, 100);"
usedProcesses[72]="Reactant_R72(R72, 100);"
usedProcesses[73]="Reactant_R73(R73, 100);"
usedProcesses[74]="Reactant_R74(R74, 100);"
usedProcesses[75]="Reactant_R75(R75, 100);"
usedProcesses[76]="Reactant_R76(R76, 100);"
usedProcesses[77]="Reactant_R77(R77, 100);"
usedProcesses[78]="Reactant_R78(R78, 100);"
usedProcesses[79]="Reactant_R79(R79, 100);"
usedProcesses[80]="Reactant_R80(R80, 100);"
usedProcesses[81]="Reactant_R81(R81, 100);"
usedProcesses[82]="Reactant_R82(R82, 100);"
usedProcesses[83]="Reactant_R83(R83, 100);"
usedProcesses[84]="Reactant_R84(R84, 100);"
usedProcesses[85]="Reactant_R85(R85, 100);"
usedProcesses[86]="Reactant_R86(R86, 100);"
usedProcesses[87]="Reactant_R87(R87, 100);"
usedProcesses[88]="Reactant_R88(R88, 100);"
usedProcesses[89]="Reactant_R89(R89, 100);"
usedProcesses[90]="Reactant_R90(R90, 100);"
usedProcesses[91]="Reactant_R91(R91, 100);"

#The xml file is the UPPAAL model: it can also be opened in the UPPAAL user interface
XMLFILE=ANIMOmodel_R_${R}.xml
#The output trace resulting from the analysis with the "simulate 1 ..." query (see ANIMOmodel.q file)
OUTPUTFILE=ANIMO_output_R${R}.txt
#The parsed traces are appended to the resulting .csv file. The header for this file is output by "run_experiment.sh" and is called "ANIMO_output.csv"
OUTPUTCSV=ANIMO_output_R${R}.csv
rm $OUTPUTCSV

for conta in `seq 1 10000`; do
	echo -n "R${R}, ${reactantIDs[$R]}, " >> $OUTPUTCSV
	cat ANIMO_header.xml > $XMLFILE
	for j in `seq 0 92`; do
		if [ "${reactantIDs[$j]}" != "" -a "${reactantVals[$j]}" == "" ]; then
			if [ $j -eq $R ]; then # The 100% reactant starts with activity = 100
				echo -e "//R$j --> ${reactantIDs[$j]}\nint R$j := 100;\nconst int R${j}Levels := 100;\n" >> $XMLFILE
				if [ "$j" -gt "0" ]; then
					echo -n ", " >> $OUTPUTCSV
				fi
				echo -n "100" >> $OUTPUTCSV
			else
				RAN=$(($RANDOM % 101))
				echo -e "//R$j --> ${reactantIDs[$j]}\nint R$j := ${RAN};\nconst int R${j}Levels := 100;\n" >> $XMLFILE
				if [ "$j" -gt "0" ]; then
					echo -n ", " >> $OUTPUTCSV
				fi
				echo -n "$RAN" >> $OUTPUTCSV
			fi
		elif [ "${reactantVals[$j]}" != "" ]; then #some (dummy) nodes are fixed
			echo -e "//R$j --> ${reactantIDs[$j]}\nint R$j := ${reactantVals[$j]};\nconst int R${j}Levels := 100;\n" >> $XMLFILE
		fi
	done
	echo -n ", " >> $OUTPUTCSV
	cat ANIMO_footer1.xml >> $XMLFILE
	echo -n "system " >> $XMLFILE
	c=0
	for j in "${!usedProcesses[@]}"; do
		if [ $j -ne $R ]; then # 100% reactants don't get changed
			if [ "$c" -eq "0" ]; then
				echo -e -n "R${j}_" >> $XMLFILE
				c=1
			else
				echo -e -n ", R${j}_" >> $XMLFILE
			fi
		fi
	done
	cat ANIMO_footer2.xml >> $XMLFILE
	$PATH_TO_VERIFYTA -s $XMLFILE ANIMOmodel.q 1> $OUTPUTFILE
	java -cp . AnalyzeResult $OUTPUTFILE >> $OUTPUTCSV
	rm $OUTPUTFILE
	rm $XMLFILE
done
