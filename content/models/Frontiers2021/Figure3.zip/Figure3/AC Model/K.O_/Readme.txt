Experiment 1b - knock-out for one node (each node in turn is set to 0% activity and kept fixed there), then compute 10 thousand simulations setting random activity for all other nodes. Compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be populated with many files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- All the *.csv files contain the results of the simulations and can be put into one single file with the command "cat ANIMO_output*.csv > Results.csv" (the header contained in the file ANIMO_output.csv should end up being the first line of Results.csv: please check that it is so).
- The results will show, for each knock-out node, the resulting percentages for Sox9, Runx2 and Null final states. Comparing these percentages to the results of experiment 1a (considering also statistical significance obtained from 0.99 confidence intervals) will give an idea of the effects of each knock-out. The category "Other" indicates a final state that is different from the three known ones (Sox9, Runx2, Null): see comment in Materials and Methods in the paper. If the percentage of "Other" states is larger than 0, furher analysis for the unrecognized states is advisable by continuing the simulation without blocking the knock-out reactant from change. Ad hoc scripts may be of help to automate this procedure.
