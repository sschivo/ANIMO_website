#!/bin/bash
#SBATCH -n 512

MODEL_NAME=$1
OUTPUT_NAME=${MODEL_NAME}_output
ERROR_NAME=${MODEL_NAME}_error

date

for i in `seq 1 512`; do
        srun --exclusive -n1 -N1 -o ${OUTPUT_NAME}$i -e ${ERROR_NAME}$i run_step.sh ${MODEL_NAME} &
        sleep 1
done
echo "Started all the experiments."
wait
date
echo "Done."

