#!/bin/bash
for t in amsc bmsc cartilage embryonic; do
	OUTPUTFILE=./${t}_result.csv
	if [ ! -f $OUTPUTFILE ]; then
		echo "Runx2,Sox9" > $OUTPUTFILE
	fi
	for i in `ls Results/*_*${t}*output*`; do
		cat $i | grep '\]:' | sed 's/.*,\(.*\))$/\1/' | split -l 114
		paste -d , xaa xab >> $OUTPUTFILE
		rm xaa xab
	done
done
