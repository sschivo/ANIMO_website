#!/bin/bash
for f in `ls *_result.csv`; do
	echo -e "\n*** ${f%_result.csv} ***" | awk '{print toupper($0) }'
	cat $f | awk -F "," '
			BEGIN {
				nNULL = 0;
				nSOX9 = 0;
				nRUNX2 = 0;
				nRows;
				costante95 = 3.8416;
				costante99 = 6.6564;
			}
			NR>1 {
				nRows++;
				if ($1 > 65 && $2 < 20) {
					nRUNX2++;
				} else if ($1 < 20 && $2 > 65) {
					nSOX9++;
				} else
					nNULL++;
			}
			END {
				percSox9 = 1.0 * nSOX9 / nRows;
				confSox9 = sqrt(costante99 * percSox9 * (1 - percSox9) / nRows) * 100;
				percSox9 = percSox9 * 100;
				printf "SOX9+: %.1f +/- %.2f (0.99 conf)\n", percSox9, confSox9;
				percRunx2 = 1.0 * nRUNX2 / nRows;
				confRunx2 = sqrt(costante99 * percRunx2 * (1 - percRunx2) / nRows) * 100;
				percRunx2 = percRunx2 * 100;
				printf "RUNX2+: %.1f +/- %.2f (0.99 conf)\n", percRunx2, confRunx2;
				percNULL = 1.0 * nNULL / nRows;
				confNULL = sqrt(costante99 * percNULL * (1 - percNULL) / nRows) * 100;
				percNULL = percNULL * 100;
				printf "NULL: %.1f +/- %.2f (0.99 conf)\n", percNULL, confNULL;
			}'
done
