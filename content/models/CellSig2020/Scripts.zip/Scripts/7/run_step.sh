#!/bin/bash
>&2 echo "Starting job with $1"
/home/schivos/uppaal64-4.1.19/bin-Linux/verifyta -s $1
>&2 echo "End of job with $1"
