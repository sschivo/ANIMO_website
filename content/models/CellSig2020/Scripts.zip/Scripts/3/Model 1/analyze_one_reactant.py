#!/usr/bin/python

import csv
import sys
import math
import os.path
import glob
import argparse

parser = argparse.ArgumentParser(description='Analyse results from ECHO experiments where one reactant is fixed on different values (e.g. 0, 10, 20, 30, ..., 100). Results must be in "./Results" and be in .csv. Give the ID of the reactant being fixed as argument with name "R" (e.g. R=8 for reactant BMP). See reactant IDs in the code.')
parser.add_argument('R', metavar='R', type=int, nargs=1,
                   help='ID of the reactant that varies in the data.')

args = parser.parse_args()
r = args.R[0]

reactantIDs = {}
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

#Allow to look for the index (in reactantIDs[]) of given reactant ID
reactantIDXs = {}
for idx, val in enumerate(reactantIDs):
	#sys.stderr.write(reactantIDs[val] + " = " + str(val) + "\n")
	reactantIDXs[reactantIDs[val]] = val

print "Fixed " + reactantIDs[r] + ";percentage Sox9;confidence interval (0.99) Sox9;percentage Runx2;confidence interval (0.99) Runx2;percentage Null;confidence interval (0.99) Null;percentage Other;confidence interval (0.99) Other;percentage Other-Sox9;confidence interval (0.99) Other-Sox9;percentage Other-Runx2;confidence interval (0.99) Other-Runx2;percentage Other-Null;confidence interval (0.99) Other-Null;Maximum difference of others;Others classified as"

# constants for computing the confidence interval
zValConf95 = 3.8416 # 95% confidence level
zValConf99 = 6.6564 # 99% confidence level
# constants for column indices
StableIDX = 0 # Stable: "TRUE"/"FALSE" to tell if the final state is stable (i.e., if no values have changed in the last 10 minutes of the 240-min simulation by more than 5/100)
Sox9IDX = 0 # Final Sox9: the activity of Sox9 node in the final state of the simulation
Runx2IDX = 0 # Final Runx2: the activity of Runx2 node in the final state of the simulation
firstFinalIDX = 0 # Index of the first of the final (post-simulation) values of the network
lastFinalIDX = 0 # Index of the last of the final (post-simulation) values of the network

headerFile = open("Results/ANIMO_output.csv", 'rt')
headerReader = csv.reader(headerFile,delimiter=",", quotechar='"')
headerNames = []
for row in headerReader:
	headerNames = row

headerFile = open("Results/ANIMO_output.csv", 'rt')
headerReader = csv.reader(headerFile,delimiter=",", quotechar='"')
conta = 0
rigaIntestazione = {}
for row in headerReader:
	rigaIntestazione = row
	for i in row:
		if (i.strip() == "Stable"):
			StableIDX = conta
		if (i.strip() == "Final Sox9"):
			Sox9IDX = conta
		if (i.strip() == "Final Runx2"):
			Runx2IDX = conta
		conta += 1
firstFinalIDX = StableIDX + 1
lastFinalIDX = conta - 1
numberOfFinals = lastFinalIDX - firstFinalIDX + 1
othersFileNames = "Others_*"
othersFiles = glob.glob(othersFileNames)
for f in othersFiles:
	os.remove(f)

for idx in range(101):
	allFileNames = "Results/ANIMO_output_R" + str(r) + "_" + str(idx) + "_*.csv"
	allFilesWithThisIndex = glob.glob(allFileNames)
	if (allFilesWithThisIndex):
		sys.stderr.write(reactantIDs[r] + " = " + str(idx))
		sys.stdout.write(str(idx) + ";")
		stableSims = 0
		sox9 = 0
		runx2 = 0
		null = 0
		others = 0
		otherSox9 = 0
		otherRunx2 = 0
		otherNull = 0
		minimo = {}
		massimo = {}
		media = {}
		for j in range(numberOfFinals):
			minimo[j] = 101
			massimo[j] = -1
			media[j] = 0.0
		for fName in allFilesWithThisIndex:
			f = open(fName, 'rt')
			reader = csv.reader(f,delimiter=",", quotechar='"')
			for row in reader:
			#	if (row[StableIDX].strip() == "TRUE"):
				stableSims += 1
				if (int(row[Sox9IDX].strip()) > 50 and int(row[Runx2IDX].strip()) < 20): #Less precise ways of determining whether a state is Sox9, Runx2 or Null
					sox9 += 1
				elif (int(row[Sox9IDX].strip()) < 20 and int(row[Runx2IDX].strip()) > 50):
					runx2 += 1
				elif (int(row[Sox9IDX].strip()) < 20 and int(row[Runx2IDX].strip()) < 20):
					null += 1
				else:
					others += 1
					for j in range(numberOfFinals):
						if (len(row[firstFinalIDX + j].strip()) > 0):
							if (minimo[j] > int(row[firstFinalIDX + j].strip())):
								minimo[j] = int(row[firstFinalIDX + j].strip())
							if (massimo[j] < int(row[firstFinalIDX + j].strip())):
								massimo[j] = int(row[firstFinalIDX + j].strip())
							media[j] += int(row[firstFinalIDX + j].strip())
		massimaDiff = 0
		othersClassifiedAs = "N/A"
		if (others > 0):
			for j in range(numberOfFinals):
				media[j] = media[j] / others
				diff = max(media[j] - minimo[j], massimo[j] - media[j])
				if (diff > massimaDiff):
					massimaDiff = diff
			#Perform one additional analysis to decide where to put these "others"
			sys.stderr.write("[One more sim...")
			f = open("execute_one_sim.sh", "w+b")
			f.write("#!/bin/bash\n")
			f.write("R=" + str(r) + "\n")
			f.write("val=" + str(idx) + "\n")
			f.write("declare -A reactantVals\n")
			for j in range(numberOfFinals):
				nome = rigaIntestazione[firstFinalIDX + j].strip()
				if (nome == ""):
					continue
				f.write('reactantVals[' + str(reactantIDXs[nome.replace("Final ", "")]) + ']=\"' + str(max(0,min(100,int(round(media[j]))))) + '\"\n')
			f.close()
			os.system("cat execute_one_sim_template.sh >> execute_one_sim.sh")
			os.system("bash execute_one_sim.sh")
			os.system("rm execute_one_sim.sh")
			#Parse the result and identify it as one of the final states, transfering the number of 'other' to that final state
			outputFile = glob.glob("ANIMO_output_R" + str(r) + "_" + str(idx) + ".csv") #The file should be only one, and contain one row
			if (outputFile):
				sys.stderr.write("*")
				for fName in outputFile:
					f = open(fName, 'rt')
					reader = csv.reader(f,delimiter=",", quotechar='"')
					for row in reader:
						if (row[StableIDX-StableIDX].strip() == "TRUE"):
							#We are relabeling the simulations currently known as "other" as one of the
							#"real" final states (sox9, runx2, null)
							if (int(row[Sox9IDX-StableIDX].strip()) > 50 and int(row[Runx2IDX-StableIDX].strip()) < 20): #Less precise ways of determining whether a state is Sox9, Runx2 or Null
								otherSox9 += others
								othersClassifiedAs = "Sox9"
							elif (int(row[Sox9IDX-StableIDX].strip()) < 20 and int(row[Runx2IDX-StableIDX].strip()) > 50):
								otherRunx2 += others
								othersClassifiedAs = "Runx2"
							elif (int(row[Sox9IDX-StableIDX].strip()) < 20 and int(row[Runx2IDX-StableIDX].strip()) < 20):
								otherNull += others
								othersClassifiedAs = "Null"
							else:
								othersClassifiedAs = "(Could not identify)"
								sys.stderr.write("Others=" + str(others))
					f.close()
					os.system("rm " + fName)
			sys.stderr.write("]")
		if (stableSims > 0):
			percSox9 = float(sox9) / stableSims
			percRunx2 = float(runx2) / stableSims
			percNull = float(null) / stableSims
			percOther = float(others) / stableSims
			percOtherSox9 = float(otherSox9) / stableSims
			percOtherRunx2 = float(otherRunx2) / stableSims
			percOtherNull = float(otherNull) / stableSims
		else:
			percSox9 = 0
			percRunx2 = 0
			percNull = 0
			percOther = 0
			percOtherSox9 = 0
			percOtherRunx2 = 0
			percOtherNull = 0
		Sox9Conf95 = math.sqrt(zValConf95 * percSox9 * (1 - percSox9) / stableSims) * 100
		Sox9Conf99 = math.sqrt(zValConf99 * percSox9 * (1 - percSox9) / stableSims) * 100
		Runx2Conf95 = math.sqrt(zValConf95 * percRunx2 * (1 - percRunx2) / stableSims) * 100
		Runx2Conf99 = math.sqrt(zValConf99 * percRunx2 * (1 - percRunx2) / stableSims) * 100
		NullConf95 = math.sqrt(zValConf95 * percNull * (1 - percNull) / stableSims) * 100
		NullConf99 = math.sqrt(zValConf99 * percNull * (1 - percNull) / stableSims) * 100
		OtherConf95 = math.sqrt(zValConf95 * percOther * (1 - percOther) / stableSims) * 100
		OtherConf99 = math.sqrt(zValConf99 * percOther * (1 - percOther) / stableSims) * 100
		OtherSox9Conf95 = math.sqrt(zValConf95 * percOtherSox9 * (1 - percOtherSox9) / stableSims) * 100
		OtherSox9Conf99 = math.sqrt(zValConf99 * percOtherSox9 * (1 - percOtherSox9) / stableSims) * 100
		OtherRunx2Conf95 = math.sqrt(zValConf95 * percOtherRunx2 * (1 - percOtherRunx2) / stableSims) * 100
		OtherRunx2Conf99 = math.sqrt(zValConf99 * percOtherRunx2 * (1 - percOtherRunx2) / stableSims) * 100
		OtherNullConf95 = math.sqrt(zValConf95 * percOtherNull * (1 - percOtherNull) / stableSims) * 100
		OtherNullConf99 = math.sqrt(zValConf99 * percOtherNull * (1 - percOtherNull) / stableSims) * 100
		sys.stdout.write("%.2f;" % (percSox9 * 100))
		sys.stdout.write("%.2f;" % Sox9Conf99)
		sys.stdout.write("%.2f;" % (percRunx2 * 100))
		sys.stdout.write("%.2f;" % Runx2Conf99)
		sys.stdout.write("%.2f;" % (percNull * 100))
		sys.stdout.write("%.2f;" % NullConf99)
		sys.stdout.write("%.2f;" % (percOther * 100))
		sys.stdout.write("%.2f;" % OtherConf99)
		sys.stdout.write("%.2f;" % (percOtherSox9 * 100))
		sys.stdout.write("%.2f;" % OtherSox9Conf99)
		sys.stdout.write("%.2f;" % (percOtherRunx2 * 100))
		sys.stdout.write("%.2f;" % OtherRunx2Conf99)
		sys.stdout.write("%.2f;" % (percOtherNull * 100))
		sys.stdout.write("%.2f;" % OtherNullConf99)
		sys.stdout.write("%.2f;" % massimaDiff)
		print(othersClassifiedAs)
	if (allFilesWithThisIndex):
		sys.stderr.write("\n")
