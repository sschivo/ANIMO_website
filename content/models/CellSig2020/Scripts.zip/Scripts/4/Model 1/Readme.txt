Experiment 1c - make two nodes vary between 0% and 100% activity on 10% steps (and kept fixed there), then compute 10 thousand simulations setting random activity for all other nodes. Compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh. Check also that R1 and R2 are set to the identifiers of the two nodes to be used
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be populated with many files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- All the *.csv files contain the results of the simulations and should be put into a directory called "Results".
- The analysis of the results can be done calling "python analyze_results.py" and passing as parameters the IDs of the two nodes (make sure to have python installed in your system). Some of the end states may have been identified as different from the three known Sox9, Runx2 and Null, and labelled as "Other": see comment in Materials and Methods in the paper. If the percentage of "Other" states is larger than 0, furher analysis for the unrecognized states is automatically performed by continuing the simulation without blocking the knock-out reactant from change thanks to a script that is generated based on the execute_one_sim_template.sh file.
- Graphs for the analyzed results can be obtained running "generate_plots.sh" passing as parameters the IDs of the two nodes (make sure that gnuplot and imagemagick are installed in your system).
