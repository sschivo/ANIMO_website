#!/bin/bash
R1=$1
R2=$2

declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

NAME1=${reactantIDs[$R1]}
NAME2=${reactantIDs[$R2]}
VS=${NAME1}vs${NAME2}
CSVFILE=Results_${VS}.csv


	gnuplot --persist <<__EOF
set datafile separator ";"
set xtics offset -2
set xlabel "${NAME1} initial activity"
set xrange [0:100]
set ytics offset 1
set ylabel "${NAME2} initial activity"
set yrange [0:100]
set zrange [0:101]
set dgrid3d 11,11
#set cntrparam levels auto 10
#set dgrid3d
set pm3d
set hidden3d
set key off
set cbrange [0:100]
set colorbox vertical user origin 0.9, .5 size .02,.4
#set palette defined ( 0 0.8 0 0, 1 0.8 0.8 0, 2 0 0.8 0 )
set palette defined ( 0 0.9 0.9 0.9, 1 0 0 0 )
#set terminal png size 960,800 enhanced truecolor font 'Verdana,11'
set terminal png size 960,960 enhanced truecolor font 'Verdana,11'

#set title "% of ${GRAPH} end states"
#set output "${VS}_${GRAPH}_map.png"
#set palette defined ( 0 '#000090', 1 '#000fff', 2 '#0090ff', 3 '#0fffee', 4 '#90ff70', 5 '#ffee00', 6 '#ff7000', 7 '#ee0000', 8 '#7f0000')
##set palette rgb 21,22,23;
#set xtics offset 0
#set ytics offset 0
#set pm3d map
#set clabel "${GRAPH}"
#set colorbox vertical default
#splot "${CSVFILE}" u 1:2:${COUNT} w d

#set title "% of ${GRAPH} end states"
unset title
set output "${VS}_map_Sox9-Runx2.png"
set palette defined ( 0 '#FF0000', 1 '#FFFF00', 2 '#00FF00' )
set xtics offset 0
set ytics offset 0
#unset xtics
#unset ytics
#unset xlabel
#unset ylabel
set pm3d map
#set clabel "${GRAPH}"
#set colorbox vertical default
unset colorbox
splot "${CSVFILE}" u 1:2:((\$3 - \$5 + 100) / 2) w d

set output "${VS}_map_Null.png"
set palette defined ( 0 '#FFFFFF', 1 '#000000' )
unset xtics
unset ytics
unset xlabel
unset ylabel
set pm3d map
splot "${CSVFILE}" u 1:2:7 w d
__EOF

convert "${VS}_map_Sox9-Runx2.png" "${VS}_map_Null.png" -alpha Off -compose CopyOpacity -composite "${VS}_map_Sox9-Runx2_trasp.png"
convert "${VS}_map_Sox9-Runx2_trasp.png" -background "#000000" -flatten "${VS}_map_Sox9-Runx2-Null.png"
rm "${VS}_map_Sox9-Runx2.png" "${VS}_map_Null.png" "${VS}_map_Sox9-Runx2_trasp.png"
