** ECHO, the executable CHOndrocyte: A computational model to study articular chondrocytes in health and disease **

Stefano Schivo, Jetse Scholma, Johan Kerkhofs, Leilei Zhong, Kannan Govindaraj, Xiaobin Huang, Jaco C. van de Pol, Rom Langerak, Andre J. van Wijnen, Liesbet Geris, Marcel Karperien, Janine N. Post


Supplemental material: Scripts to run the in silico experiments on the ECHO model.


This is an index of all scripts to run the in silico experiments described in the manuscript. For each experiment, we refer the figures/tables used in the manuscript and in the accompanying MethodsX paper.


Individual Readme.txt files are available inside each experiment directory, together with input files. Scripts to run the experiments and to analyze the results are also included.
The four different versions of the ECHO model are numbered from 1 (also called "growth plate model" in the manuscript) to 4 ("articular cartilage model"). Figure X6A in the MethodsX paper displays the differences among the four versions of ECHO. All experiments apart from numbers 7 and 8 were executed on all four versions of ECHO.

2 - (Figure 2)
1 million simulations starting from random activity for all nodes, compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

3 - (Figure 3): make one node vary between 0% and 100% activity on 10% steps (and kept fixed there), then compute 10 thousand simulations setting random activity for all other nodes. Compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

4 - (Figure 4): make two nodes vary between 0% and 100% activity on 10% steps (and kept fixed there), then compute 10 thousand simulations setting random activity for all other nodes. Compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

5 - 
* Combination Dosage (Figure 5, tables) *
choose between +1 (overactivation), 0 (no change), -1 (knock-out) for each of the 7 "input" nodes to ECHO (overactivation and knock-out mean that activity of 100% and 0%, respectively, are set and kept fixed), which are WNT, IGF-1, BMP, FGF, TGFbeta, Ihh, PTHrP. All other nodes are initialized as the given state (choice is between Runx2- or Sox9-positive). Compute one simulation for each configuration, to see if a switch to another state can be achieved, and collect the results in a table.
* Input Combinations (Figure 5, graphs) *
make two nodes vary between 0% and 100% activity on 1% steps (and kept fixed there), then compute one simulation setting all other nodes to their activity in the chosen stable state (Runx2- or Sox9-positive). The final states of the network for all the configurations are collected in a table and can be displayed as graphs. We executed this experiment for those combinations that gave a switch (Sox9-positive to Runx2-positive or vice versa) in the "Combination Dosage" experiment.

6 - 
* Single-node dosage (Figure 5, graphs where a single node changes) *
make one node vary between 0% and 100% activity on 1% steps (and kept fixed there), then compute one simulation setting all other nodes to their activity in the chosen stable state (Runx2- or Sox9-positive). The final states of the network for all the configurations are collected in a table and can be displayed as graphs.

7 - (Figure 6): differentiation results of four cell types under various differentiation stimuli. For each cell type and each stimulus, compute 10 thousand simulations and infer the percentage of configurations ending in a Sox9-positive, Runx2-positive and Null state. Nodes are initialized according to the cell type and differentiation stimulus; the initial activity levels of all nodes not involved in differentiation or cell type determination are randomly chosen.

8 - (Figure 7): enable/disable the three nodes DKK1/FRZB/GREM1 in the SOX9-positive and RUNX2-positive models, add IL-1b and perform one simulation. This experiment was not carried out using the cluster, so we provide the starting model in its two initial configurations: use ANIMO's Enable/Disable feature (right click on a node --> ANIMO --> Enable/Disable) to adapt the initial state before performing a simulation.

All .sh scripts are BASH shell scripts, so a GNU/Linux environment is recommended to execute them. The "run_experiment.sh" and "run_script.sh" scripts are made to be run on a SLURM cluster, see https://slurm.schedmd.com/slurm.html
Java programs and Python scripts are occasionally used to analyze the results, so a working Java Virtual Machine and a Python interpreter are also recommended.
For some experiments, we included additional shell scripts to generate graphs of the results using gnuplot.
