Experiment 2b - knock-out or overactivation for one node (each node in turn is set to 100% or 0% activity and kept fixed there), then compute one simulation setting the activity for all other nodes as it is in the chosen stable state (Runx2- or Sox9-positive are considered). The configurations and final states are collected in a table.

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable, and that the initial state is selected
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be populated with many files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- All the *.csv files contain the results of the simulations, and can be put into one single file with the command "cat ANIMO_output*.csv > Results.csv" (the header contained in the file ANIMO_output.csv should end up being the first line of Results.csv: please check that it is so).
- The results will show, for each node, the result of its modification (overactivation or k.o.) in terms of activity of all the nodes after a simulation. Switches of state (Runx2-positive <--> Sox9-positive) can be detected in this way.
