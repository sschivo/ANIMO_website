Experiment 2b - make one node vary between 0% and 100% activity on 1% steps (and kept fixed there), then compute one simulation setting all other nodes to their activity in the chosen stable state (Runx2- or Sox9-positive). The final states of the network for all the configurations are collected in a table and can be displayed as graphs.

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be contain one or more files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- The analysis of the results can be done calling "analyze_results.sh".
- Graphs for the analyzed results can be obtained running "plot_graphs.sh" (make sure that gnuplot and imagemagick are installed in your system).
