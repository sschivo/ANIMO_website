#!/bin/bash
#We consider the results from the experiments with Runx2-positive initial state. To consider Sox9-positive instead, please change the commented for below

declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

WNT=88
IGF1=47
BMP=8
FGF=31
TGFB=87
IHH=51
PTHRP=74

#THIS FOR
#Uncomment the following line and comment the one below if you want to start from a Sox9-positive state instead of Runx2-positive
for paio in $TGFB:$IHH $FGF:$TGFB $BMP:$TGFB $IGF1:$TGFB $WNT:$TGFB; do
#for paio in $BMP:$PTHRP $BMP:$IHH $BMP:$TGFB $IGF1:$BMP $WNT:$PTHRP $WNT:$IHH $WNT:$TGFB $WNT:$FGF $WNT:$IGF1; do
	R1=${paio%:*};
	R2=${paio#*:};
	NAME1=${reactantIDs[${R1}]}
	NAME2=${reactantIDs[${R2}]}
	VS=${NAME1}vs${NAME2}
	CSVDIR=Results_${VS}
	mkdir ${CSVDIR}
	OUTPUT_CSV=Results_${VS}.csv
	TMP_CSV=Results_${VS}_tmp.csv
	cat ${CSVDIR}/ANIMO_output_R${R1}_R${R2}.csv > ${TMP_CSV}
	cat ${CSVDIR}/ANIMO_output*R${R1}_*R${R2}_*.csv >> ${TMP_CSV}
	cat ${TMP_CSV} | awk -F "," 'NR==1{ runx2 = 0; sox9 = 0; for (i=1;i<=NF;i++) { if ($i=="Runx2") runx2=i; else if ($i=="Sox9") sox9=i; } }{for (i=1;i<=NF;i++) if (i==1 || i==2 || i==runx2) printf "%s,", $i; else if (i==sox9) print $i }' > ${OUTPUT_CSV}
	rm ${TMP_CSV}
done
