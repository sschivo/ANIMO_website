#!/bin/bash

#By default, the initial state is Runx2-positive. If you want to use Sox9-positive please modify the assignment at the beginning of run_step.sh and also go towards the end of this file and look for the "for" with all pairs: uncomment one and comment the other

WNT=88
IGF1=47
BMP=8
FGF=31
TGFB=87
IHH=51
PTHRP=74

#THIS FOR
#Uncomment the following line and comment the one below if you want to start from a Sox9-positive state instead of Runx2-positive
for paio in $TGFB:$IHH $FGF:$TGFB $BMP:$TGFB $IGF1:$TGFB $WNT:$TGFB; do
#for paio in $BMP:$BMP $WNT:$WNT $TGFB:$IHH $BMP:$PTHRP $BMP:$IHH $BMP:$TGFB $IGF1:$BMP $WNT:$PTHRP $WNT:$IHH $WNT:$TGFB $WNT:$FGF $WNT:$IGF1; do
	R1=${paio%:*};
	R2=${paio#*:};
	sbatch run_experiment.sh $R1 $R2
done
