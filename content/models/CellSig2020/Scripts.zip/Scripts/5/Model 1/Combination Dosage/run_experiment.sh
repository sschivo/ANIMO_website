#!/bin/bash
#SBATCH -o _ANIMO.out
#SBATCH -e _ANIMO.err
#SBATCH -n 101
#We use 101 cores in this case (from activity 0 to activity 100). If you want to use a different number of cores, please change also the distribution of the simulations among the jobs.

declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

date

WNT=88
IGF1=47
BMP=8
FGF=31
TGFB=87
IHH=51
PTHRP=74

R1=$1
R2=$2
OUTPUT_CSV=ANIMO_output_R${R1}_R${R2}.csv
rm -f $OUTPUT_CSV

echo -n "Fixed ${reactantIDs[$R1]},Fixed ${reactantIDs[$R2]}," > $OUTPUT_CSV
echo -e -n "Stable," >> $OUTPUT_CSV
for idx in `seq 0 92`; do
	if [ "${reactantIDs[$idx]}" != "" ]; then
		echo -n "${reactantIDs[$idx]}," >> $OUTPUT_CSV
	fi
done
echo "" >> $OUTPUT_CSV

COUNTER=0
for val1 in `seq 0 100`; do
	srun --exclusive -n1 -N1 -o _ANIMO_M1_${R1}_${val1}_${R2}_0-100.out esegui_passo.pbs ${R1} ${val1} ${R2} & 
	let COUNTER=COUNTER+1
	if [ $COUNTER -ge 20 ]; then
		sleep 1
		let COUNTER=0
	fi
done
echo "Started all the simulations for ${reactantIDs[$R1]} vs ${reactantIDs[$R2]}"
wait
date
echo "Done ${reactantIDs[$R1]} vs ${reactantIDs[$R2]}."
