Experiment 2a - choose between +1 (overactivation), 0 (no change), -1 (knock-out) for each of the 7 "input" nodes to ECHO (overactivation and knock-out mean that activity of 100% and 0%, respectively, are set and kept fixed), which are WNT, IGF-1, BMP, FGF, TGFbeta, Ihh, PTHrP. All other nodes are initialized as the given state (choice is between Runx2- or Sox9-positive). Compute one simulation for each configuration, to see if a switch to another state can be achieved, and collect the results in a table.

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores you want to use in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable and choose the initial state
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be populated with many files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- All the *.csv files contain the results of the simulations and can be put into one single file with the command "cat ANIMO_output*.csv > Results.csv" (the header contained in the file ANIMO_output.csv should end up being the first line of Results.csv: please check that it is so).
- The results will show, for each combination of the input nodes, the resulting activities of all nodes in the network. The "Stable" column contains FALS if any node in the network oscillates by more than 5% in the last 10 minutes of simulation. The final state for each input combination defines whether the network has transitioned to a different state (e.g. from Runx2- to Sox9-positive).
