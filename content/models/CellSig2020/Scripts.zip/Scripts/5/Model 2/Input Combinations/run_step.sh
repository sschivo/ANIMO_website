#!/bin/bash
#Try all combinations of +1 (overactivation, kept fixed), 0 (activity set as in given initial state, let free to change), -1 (knock-out, kept fixed at 0 activity) of the 7 input to ECHO (WNT, IGF-1, BMP, FGF, TGFbeta, Ihh, PTHrP), starting from the given (by default, Runx2-positive) state. Save the resulting final states in a table.
#The choices for Wnt and IGF-1 are given as parameters (so we intend to run 9 processes in parallel)

#Replace the content of PATH_TO_VERIFYTA with the path to the "verifyta" executable of UPPAAL
PATH_TO_VERIFYTA=/home/schivos/uppaal/bin-Linux/verifyta

#The initial state is Runx2-positive. Change to Sox9 to start from Sox9-positive
start=Runx2


WNT=$1
IGF1=$2

idxWNT=88
idxIGF1=47
idxBMP=8
idxFGF=31
idxTGFB=87
idxIHH=51
idxPTHRP=74

declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"

declare -A reactantVals
#Runx2 initial state
reactantVals[Runx2,0]="0"
reactantVals[Runx2,1]="0"
reactantVals[Runx2,2]="0"
reactantVals[Runx2,3]="66"
reactantVals[Runx2,4]="66"
reactantVals[Runx2,5]="67"
reactantVals[Runx2,6]="100"
reactantVals[Runx2,7]="92"
reactantVals[Runx2,8]="100"
reactantVals[Runx2,9]="100"
reactantVals[Runx2,10]="84"
reactantVals[Runx2,11]="100"
reactantVals[Runx2,12]="16"
reactantVals[Runx2,13]="53"
reactantVals[Runx2,14]="100"
reactantVals[Runx2,15]="29"
reactantVals[Runx2,16]="44"
reactantVals[Runx2,17]="100"
reactantVals[Runx2,18]="17"
reactantVals[Runx2,19]="50"
reactantVals[Runx2,20]="100"
reactantVals[Runx2,21]="100"
reactantVals[Runx2,22]="0"
reactantVals[Runx2,23]="67"
reactantVals[Runx2,24]="100"
reactantVals[Runx2,25]="67"
reactantVals[Runx2,26]="83"
reactantVals[Runx2,27]="100"
reactantVals[Runx2,28]="0"
reactantVals[Runx2,29]="100"
reactantVals[Runx2,30]="0"
reactantVals[Runx2,31]="100"
reactantVals[Runx2,32]="100"
reactantVals[Runx2,33]="100"
reactantVals[Runx2,34]="100"
reactantVals[Runx2,35]="0"
reactantVals[Runx2,36]="100"
reactantVals[Runx2,37]="0"
reactantVals[Runx2,38]="0"
reactantVals[Runx2,39]="100"
reactantVals[Runx2,40]="0"
reactantVals[Runx2,41]="100"
reactantVals[Runx2,42]="0"
reactantVals[Runx2,43]="100"
reactantVals[Runx2,44]="67"
reactantVals[Runx2,45]="0"
reactantVals[Runx2,46]="100"
reactantVals[Runx2,47]="0"
reactantVals[Runx2,48]="0"
reactantVals[Runx2,49]="0"
reactantVals[Runx2,50]="100"
reactantVals[Runx2,51]="100"
reactantVals[Runx2,52]="91"
reactantVals[Runx2,53]="91"
reactantVals[Runx2,54]="100"
reactantVals[Runx2,55]="100"
reactantVals[Runx2,56]="67"
reactantVals[Runx2,57]="100"
reactantVals[Runx2,58]="67"
reactantVals[Runx2,59]="84"
reactantVals[Runx2,60]="0"
reactantVals[Runx2,61]="33"
reactantVals[Runx2,62]="100"
reactantVals[Runx2,63]="0"
reactantVals[Runx2,64]="100"
reactantVals[Runx2,65]="0"
reactantVals[Runx2,66]="67"
reactantVals[Runx2,67]="67"
reactantVals[Runx2,68]="100"
reactantVals[Runx2,69]="0"
reactantVals[Runx2,70]="0"
reactantVals[Runx2,71]="0"
reactantVals[Runx2,72]="0"
reactantVals[Runx2,73]="15"
reactantVals[Runx2,74]="0"
reactantVals[Runx2,75]="35"
reactantVals[Runx2,76]="100"
reactantVals[Runx2,77]="100"
reactantVals[Runx2,78]="100"
reactantVals[Runx2,79]="100"
reactantVals[Runx2,80]="44"
reactantVals[Runx2,81]="0"
reactantVals[Runx2,82]="65"
reactantVals[Runx2,83]="0"
reactantVals[Runx2,84]="0"
reactantVals[Runx2,85]="0"
reactantVals[Runx2,86]="33"
reactantVals[Runx2,87]="67"
reactantVals[Runx2,88]="100"
reactantVals[Runx2,89]="67"
reactantVals[Runx2,90]="8"
reactantVals[Runx2,91]="100"

#Sox9 initial state
reactantVals[Sox9,0]="0"
reactantVals[Sox9,1]="1"
reactantVals[Sox9,2]="7"
reactantVals[Sox9,3]="67"
reactantVals[Sox9,4]="0"
reactantVals[Sox9,5]="0"
reactantVals[Sox9,6]="0"
reactantVals[Sox9,7]="0"
reactantVals[Sox9,8]="0"
reactantVals[Sox9,9]="100"
reactantVals[Sox9,10]="0"
reactantVals[Sox9,11]="0"
reactantVals[Sox9,12]="57"
reactantVals[Sox9,13]="72"
reactantVals[Sox9,14]="100"
reactantVals[Sox9,15]="79"
reactantVals[Sox9,16]="88"
reactantVals[Sox9,17]="0"
reactantVals[Sox9,18]="100"
reactantVals[Sox9,19]="100"
reactantVals[Sox9,20]="100"
reactantVals[Sox9,21]="100"
reactantVals[Sox9,22]="100"
reactantVals[Sox9,23]="0"
reactantVals[Sox9,24]="12"
reactantVals[Sox9,25]="0"
reactantVals[Sox9,26]="0"
reactantVals[Sox9,27]="0"
reactantVals[Sox9,28]="4"
reactantVals[Sox9,29]="66"
reactantVals[Sox9,30]="7"
reactantVals[Sox9,31]="0"
reactantVals[Sox9,32]="0"
reactantVals[Sox9,33]="0"
reactantVals[Sox9,34]="0"
reactantVals[Sox9,35]="0"
reactantVals[Sox9,36]="0"
reactantVals[Sox9,37]="100"
reactantVals[Sox9,38]="100"
reactantVals[Sox9,39]="0"
reactantVals[Sox9,40]="100"
reactantVals[Sox9,41]="100"
reactantVals[Sox9,42]="0"
reactantVals[Sox9,43]="100"
reactantVals[Sox9,44]="28"
reactantVals[Sox9,45]="0"
reactantVals[Sox9,46]="0"
reactantVals[Sox9,47]="100"
reactantVals[Sox9,48]="21"
reactantVals[Sox9,49]="100"
reactantVals[Sox9,50]="21"
reactantVals[Sox9,51]="43"
reactantVals[Sox9,52]="0"
reactantVals[Sox9,53]="0"
reactantVals[Sox9,54]="100"
reactantVals[Sox9,55]="44"
reactantVals[Sox9,56]="0"
reactantVals[Sox9,57]="12"
reactantVals[Sox9,58]="0"
reactantVals[Sox9,59]="0"
reactantVals[Sox9,60]="7"
reactantVals[Sox9,61]="100"
reactantVals[Sox9,62]="100"
reactantVals[Sox9,63]="7"
reactantVals[Sox9,64]="0"
reactantVals[Sox9,65]="100"
reactantVals[Sox9,66]="0"
reactantVals[Sox9,67]="14"
reactantVals[Sox9,68]="0"
reactantVals[Sox9,69]="100"
reactantVals[Sox9,70]="100"
reactantVals[Sox9,71]="63"
reactantVals[Sox9,72]="78"
reactantVals[Sox9,73]="81"
reactantVals[Sox9,74]="78"
reactantVals[Sox9,75]="0"
reactantVals[Sox9,76]="0"
reactantVals[Sox9,77]="0"
reactantVals[Sox9,78]="0"
reactantVals[Sox9,79]="0"
reactantVals[Sox9,80]="7"
reactantVals[Sox9,81]="7"
reactantVals[Sox9,82]="4"
reactantVals[Sox9,83]="0"
reactantVals[Sox9,84]="100"
reactantVals[Sox9,85]="100"
reactantVals[Sox9,86]="100"
reactantVals[Sox9,87]="28"
reactantVals[Sox9,88]="0"
reactantVals[Sox9,89]="3"
reactantVals[Sox9,90]="100"
reactantVals[Sox9,91]="19"

declare -A dummies
dummies[9]="100"
dummies[14]="100"
dummies[20]="100"
dummies[21]="100"
dummies[43]="100"
dummies[54]="100"
dummies[62]="100"

declare -A usedProcesses
usedProcesses[0]="Reactant_R0(R0, 100);"
usedProcesses[1]="Reactant_R1(R1, 100);"
usedProcesses[2]="Reactant_R2(R2, 100);"
usedProcesses[3]="Reactant_R3(R3, 100);"
usedProcesses[4]="Reactant_R4(R4, 100);"
usedProcesses[5]="Reactant_R5(R5, 100);"
usedProcesses[6]="Reactant_R6(R6, 100);"
usedProcesses[7]="Reactant_R7(R7, 100);"
usedProcesses[8]="Reactant_R8(R8, 100);"
usedProcesses[10]="Reactant_R10(R10, 100);"
usedProcesses[11]="Reactant_R11(R11, 100);"
usedProcesses[12]="Reactant_R12(R12, 100);"
usedProcesses[13]="Reactant_R13(R13, 100);"
usedProcesses[15]="Reactant_R15(R15, 100);"
usedProcesses[16]="Reactant_R16(R16, 100);"
usedProcesses[17]="Reactant_R17(R17, 100);"
usedProcesses[18]="Reactant_R18(R18, 100);"
usedProcesses[19]="Reactant_R19(R19, 100);"
usedProcesses[22]="Reactant_R22(R22, 100);"
usedProcesses[23]="Reactant_R23(R23, 100);"
usedProcesses[24]="Reactant_R24(R24, 100);"
usedProcesses[25]="Reactant_R25(R25, 100);"
usedProcesses[26]="Reactant_R26(R26, 100);"
usedProcesses[27]="Reactant_R27(R27, 100);"
usedProcesses[28]="Reactant_R28(R28, 100);"
usedProcesses[29]="Reactant_R29(R29, 100);"
usedProcesses[30]="Reactant_R30(R30, 100);"
usedProcesses[31]="Reactant_R31(R31, 100);"
usedProcesses[32]="Reactant_R32(R32, 100);"
usedProcesses[33]="Reactant_R33(R33, 100);"
usedProcesses[34]="Reactant_R34(R34, 100);"
usedProcesses[35]="Reactant_R35(R35, 100);"
usedProcesses[36]="Reactant_R36(R36, 100);"
usedProcesses[37]="Reactant_R37(R37, 100);"
usedProcesses[38]="Reactant_R38(R38, 100);"
usedProcesses[39]="Reactant_R39(R39, 100);"
usedProcesses[40]="Reactant_R40(R40, 100);"
usedProcesses[41]="Reactant_R41(R41, 100);"
usedProcesses[42]="Reactant_R42(R42, 100);"
usedProcesses[44]="Reactant_R44(R44, 100);"
usedProcesses[45]="Reactant_R45(R45, 100);"
usedProcesses[46]="Reactant_R46(R46, 100);"
usedProcesses[47]="Reactant_R47(R47, 100);"
usedProcesses[48]="Reactant_R48(R48, 100);"
usedProcesses[49]="Reactant_R49(R49, 100);"
usedProcesses[50]="Reactant_R50(R50, 100);"
usedProcesses[51]="Reactant_R51(R51, 100);"
usedProcesses[52]="Reactant_R52(R52, 100);"
usedProcesses[53]="Reactant_R53(R53, 100);"
usedProcesses[55]="Reactant_R55(R55, 100);"
usedProcesses[56]="Reactant_R56(R56, 100);"
usedProcesses[57]="Reactant_R57(R57, 100);"
usedProcesses[58]="Reactant_R58(R58, 100);"
usedProcesses[59]="Reactant_R59(R59, 100);"
usedProcesses[60]="Reactant_R60(R60, 100);"
usedProcesses[61]="Reactant_R61(R61, 100);"
usedProcesses[63]="Reactant_R63(R63, 100);"
usedProcesses[64]="Reactant_R64(R64, 100);"
usedProcesses[65]="Reactant_R65(R65, 100);"
usedProcesses[66]="Reactant_R66(R66, 100);"
usedProcesses[67]="Reactant_R67(R67, 100);"
usedProcesses[68]="Reactant_R68(R68, 100);"
usedProcesses[69]="Reactant_R69(R69, 100);"
usedProcesses[70]="Reactant_R70(R70, 100);"
usedProcesses[71]="Reactant_R71(R71, 100);"
usedProcesses[72]="Reactant_R72(R72, 100);"
usedProcesses[73]="Reactant_R73(R73, 100);"
usedProcesses[74]="Reactant_R74(R74, 100);"
usedProcesses[75]="Reactant_R75(R75, 100);"
usedProcesses[76]="Reactant_R76(R76, 100);"
usedProcesses[77]="Reactant_R77(R77, 100);"
usedProcesses[78]="Reactant_R78(R78, 100);"
usedProcesses[79]="Reactant_R79(R79, 100);"
usedProcesses[80]="Reactant_R80(R80, 100);"
usedProcesses[81]="Reactant_R81(R81, 100);"
usedProcesses[82]="Reactant_R82(R82, 100);"
usedProcesses[83]="Reactant_R83(R83, 100);"
usedProcesses[84]="Reactant_R84(R84, 100);"
usedProcesses[85]="Reactant_R85(R85, 100);"
usedProcesses[86]="Reactant_R86(R86, 100);"
usedProcesses[87]="Reactant_R87(R87, 100);"
usedProcesses[88]="Reactant_R88(R88, 100);"
usedProcesses[89]="Reactant_R89(R89, 100);"
usedProcesses[90]="Reactant_R90(R90, 100);"
usedProcesses[91]="Reactant_R91(R91, 100);"

#Total: 3^5 = 243 simulations
for BMP in -1 0 1; do
	for FGF in -1 0 1; do
		for TGFB in -1 0 1; do
			for IHH in -1 0 1; do
				for PTHRP in -1 0 1; do
					XMLFILE=ANIMOmodel_${WNT}_${IGF1}_${BMP}_${FGF}_${TGFB}_${IHH}_${PTHRP}.xml
					OUTPUTFILE=ANIMO_output_${WNT}_${IGF1}_${BMP}_${FGF}_${TGFB}_${IHH}_${PTHRP}.txt
					CSVFILE=ANIMO_output_${WNT}_${IGF1}_${BMP}_${FGF}_${TGFB}_${IHH}_${PTHRP}.csv
					cat ANIMO_header.xml > $XMLFILE
					for j in `seq 0 92`; do
						if [ "${reactantIDs[$j]}" != "" ]; then
							echo -e -n "//R$j --> ${reactantIDs[$j]}\nint R$j := " >> $XMLFILE
							if [ $idxWNT -eq $j ]; then
								nomeVar=WNT
							elif [ $idxIGF1 -eq $j ]; then
								nomeVar=IGF1
							elif [ $idxBMP -eq $j ]; then
								nomeVar=BMP
							elif [ $idxFGF -eq $j ]; then
								nomeVar=FGF
							elif [ $idxTGFB -eq $j ]; then
								nomeVar=TGFB
							elif [ $idxIHH -eq $j ]; then
								nomeVar=IHH
							elif [ $idxPTHRP -eq $j ]; then
								nomeVar=PTHRP
							else
								nomeVar=""
							fi
							if [ "${nomeVar}" != "" ]; then
								if [ ${!nomeVar} -eq -1 ]; then
									echo -e -n "0;\n" >> $XMLFILE
								elif [ ${!nomeVar} -eq 0 ]; then
									echo -e -n "${reactantVals[$start,$j]};\n" >> $XMLFILE
								elif [ ${!nomeVar} -eq 1 ]; then
									echo -e -n "100;\n" >> $XMLFILE
								else
									echo -e -n "${reactantVals[$start,$j]};\n" >> $XMLFILE
								fi
							else
								echo -e -n "${reactantVals[$start,$j]};\n" >> $XMLFILE
							fi
							echo -e -n "const int R${j}Levels := 100;\n" >> $XMLFILE
						elif [ "${dummies[$j]}" != "" ]; then
							echo -e -n "int R$j := ${reactantVals[$start,$j]};\nconst int R${j}Levels := 100;\n" >> $XMLFILE
						fi
					done
					cat ANIMO_footer1.xml >> $XMLFILE
					echo -n "system " >> $XMLFILE
					c=0
					for j in "${!usedProcesses[@]}"; do
						if [ $idxWNT -eq $j ]; then
							nomeVar=WNT
						elif [ $idxIGF1 -eq $j ]; then
							nomeVar=IGF1
						elif [ $idxBMP -eq $j ]; then
							nomeVar=BMP
						elif [ $idxFGF -eq $j ]; then
							nomeVar=FGF
						elif [ $idxTGFB -eq $j ]; then
							nomeVar=TGFB
						elif [ $idxIHH -eq $j ]; then
							nomeVar=IHH
						elif [ $idxPTHRP -eq $j ]; then
							nomeVar=PTHRP
						else
							nomeVar=""
						fi
						if [ "${nomeVar}" != "" ]; then
							if [ ${!nomeVar} -eq 0 ]; then #If ${!nomeVar} is "0", we want to keep the variable $nomeVar as it is, and also to respond to changes from the network
								if [ "$c" -eq "0" ]; then
									echo -e -n "R${j}_" >> $XMLFILE
									c=1
								else
									echo -e -n ", R${j}_" >> $XMLFILE
								fi
							fi
						else
							if [ "$c" -eq "0" ]; then
								echo -e -n "R${j}_" >> $XMLFILE
								c=1
							else
								echo -e -n ", R${j}_" >> $XMLFILE
							fi
						fi
					done
					cat ANIMO_footer2.xml >> $XMLFILE
					$PATH_TO_VERIFYTA -s $XMLFILE ANIMOmodel.q 1> $OUTPUTFILE 2>/dev/null
					echo -e -n "${WNT},${IGF1},${BMP},${FGF},${TGFB},${IHH},${PTHRP}," > $CSVFILE
					java -cp . AnalyzeResult $OUTPUTFILE >> $CSVFILE
					rm $OUTPUTFILE
					rm $XMLFILE
				done
			done
		done
	done
done
