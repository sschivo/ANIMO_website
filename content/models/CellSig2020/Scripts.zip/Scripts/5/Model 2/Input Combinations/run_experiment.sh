#!/bin/bash
#SBATCH -o _ANIMO.out
#SBATCH -n 9
#The line above says that we are going to use 9 cores (we define 3 * 3 combinations for Wnt and IGF-1, and let the single processes do the other 3^5 combinations for the remaining 5 input nodes)
declare -A reactantIDs
reactantIDs[0]="ATF2"
reactantIDs[1]="ATF2 PTM"
reactantIDs[2]="ATF2 prot"
reactantIDs[3]="ATF4"
reactantIDs[4]="Akt"
reactantIDs[5]="Akt PTM"
reactantIDs[6]="Akt prot"
reactantIDs[7]="B-catenin"
reactantIDs[8]="BMP"
reactantIDs[10]="Bcatleftcfcomplex"
reactantIDs[11]="C/EBPb dummy"
reactantIDs[12]="CCND1"
reactantIDs[13]="CCND1 PTM"
reactantIDs[15]="CCND1 prot"
reactantIDs[16]="Col-II"
reactantIDs[17]="Col-X"
reactantIDs[18]="DC canonical dummy"
reactantIDs[19]="DC degradation dummy"
reactantIDs[22]="DKK1"
reactantIDs[23]="Dlx5"
reactantIDs[24]="Dlx5 PTM"
reactantIDs[25]="Dlx5 prot"
reactantIDs[26]="Dsh"
reactantIDs[27]="ERK1/2"
reactantIDs[28]="Ets1"
reactantIDs[29]="Ets1 PTM"
reactantIDs[30]="Ets1 prot"
reactantIDs[31]="FGF"
reactantIDs[32]="FGFR1"
reactantIDs[33]="FGFR1 PTM"
reactantIDs[34]="FGFR1 prot"
reactantIDs[35]="FGFR3"
reactantIDs[36]="FGFR3 PTM"
reactantIDs[37]="FGFR3 prot"
reactantIDs[38]="FRZB"
reactantIDs[39]="Frizzled - LRP 5/6"
reactantIDs[40]="GREM1"
reactantIDs[41]="GSK"
reactantIDs[42]="GSK dummy"
reactantIDs[44]="Gli2"
reactantIDs[45]="HDAC4"
reactantIDs[46]="HIF-2a"
reactantIDs[47]="IGF-1"
reactantIDs[48]="IGF-1R"
reactantIDs[49]="IGF-1R PTM"
reactantIDs[50]="IGF-1R prot"
reactantIDs[51]="Ihh"
reactantIDs[52]="Lef/Tcf"
reactantIDs[53]="Lef/Tcf PTM"
reactantIDs[55]="Lef/Tcf prot"
reactantIDs[56]="MEF2C"
reactantIDs[57]="MEF2C PTM"
reactantIDs[58]="MEF2C prot"
reactantIDs[59]="MMP13"
reactantIDs[60]="Msx2"
reactantIDs[61]="Msx2 PTM"
reactantIDs[63]="Msx2 prot"
reactantIDs[64]="NFkb"
reactantIDs[65]="Nkx3.2"
reactantIDs[66]="PI3K"
reactantIDs[67]="PI3K PTM"
reactantIDs[68]="PI3K prot"
reactantIDs[69]="PKA"
reactantIDs[70]="PP2A"
reactantIDs[71]="PPR"
reactantIDs[72]="PPR PTM"
reactantIDs[73]="PPR prot"
reactantIDs[74]="PTHrP"
reactantIDs[75]="R-smad"
reactantIDs[76]="Ras"
reactantIDs[77]="Runx2"
reactantIDs[78]="Runx2 PTM"
reactantIDs[79]="Runx2 prot"
reactantIDs[80]="STAT1"
reactantIDs[81]="Smad3"
reactantIDs[82]="Smad7"
reactantIDs[83]="Smadcomplex"
reactantIDs[84]="Sox9"
reactantIDs[85]="Sox9 PTM"
reactantIDs[86]="Sox9 prot"
reactantIDs[87]="TGFb"
reactantIDs[88]="Wnt"
reactantIDs[89]="dEF-1"
reactantIDs[90]="destruction complex"
reactantIDs[91]="p38"


echo -e -n "Wnt,IGF-1,BMP,FGF,TGFb,Ihh,PTHrP,Stable," > ANIMO_output.csv
c=0
for idx in `seq 0 92`; do
	if [ "${reactantIDs[$idx]}" != "" ]; then
		if [ $c -eq 0 ]; then
			c=1
		else
			echo -n "," >> ANIMO_output.csv
		fi
		echo -n "${reactantIDs[$idx]}" >> ANIMO_output.csv
	fi
done
echo "" >> ANIMO_output.csv

date
COUNTER=0
for WNT in -1 0 1; do
	for IGF1 in -1 0 1; do
		srun --exclusive -n1 -N1 -o _ANIMO_WNT${WNT}_IGF1${IGF1}.out run_step.sh ${WNT} ${IGF1} &
		let COUNTER=COUNTER+1
		if [ $COUNTER -ge 20 ]; then
			sleep 1
			let COUNTER=0
		fi
	done
done
echo "Started ${COUNTER} jobs."
wait
date
echo "Done."
