import java.io.*;
import java.util.*;
import java.util.regex.*;

public class AnalyzeResult {
	private final String[] reactantIDs = new String[93];
	private final int LAST_MINUTES = 55000; //10 minutes
	private int lastValues[] = new int[93];

	public AnalyzeResult() {
		for (int i=0;i<reactantIDs.length;i++) {
			reactantIDs[i] = null;
		}
		reactantIDs[0]="ATF2";
		reactantIDs[1]="ATF2 PTM";
		reactantIDs[2]="ATF2 prot";
		reactantIDs[3]="ATF4";
		reactantIDs[4]="Akt";
		reactantIDs[5]="Akt PTM";
		reactantIDs[6]="Akt prot";
		reactantIDs[7]="B-catenin";
		reactantIDs[8]="BMP";
		reactantIDs[10]="Bcatleftcfcomplex";
		reactantIDs[11]="C/EBPb dummy";
		reactantIDs[12]="CCND1";
		reactantIDs[13]="CCND1 PTM";
		reactantIDs[15]="CCND1 prot";
		reactantIDs[16]="Col-II";
		reactantIDs[17]="Col-X";
		reactantIDs[18]="DC canonical dummy";
		reactantIDs[19]="DC degradation dummy";
		reactantIDs[22]="DKK1";
		reactantIDs[23]="Dlx5";
		reactantIDs[24]="Dlx5 PTM";
		reactantIDs[25]="Dlx5 prot";
		reactantIDs[26]="Dsh";
		reactantIDs[27]="ERK1/2";
		reactantIDs[28]="Ets1";
		reactantIDs[29]="Ets1 PTM";
		reactantIDs[30]="Ets1 prot";
		reactantIDs[31]="FGF";
		reactantIDs[32]="FGFR1";
		reactantIDs[33]="FGFR1 PTM";
		reactantIDs[34]="FGFR1 prot";
		reactantIDs[35]="FGFR3";
		reactantIDs[36]="FGFR3 PTM";
		reactantIDs[37]="FGFR3 prot";
		reactantIDs[38]="FRZB";
		reactantIDs[39]="Frizzled - LRP 5/6";
		reactantIDs[40]="GREM1";
		reactantIDs[41]="GSK";
		reactantIDs[42]="GSK dummy";
		reactantIDs[44]="Gli2";
		reactantIDs[45]="HDAC4";
		reactantIDs[46]="HIF-2a";
		reactantIDs[47]="IGF-1";
		reactantIDs[48]="IGF-1R";
		reactantIDs[49]="IGF-1R PTM";
		reactantIDs[50]="IGF-1R prot";
		reactantIDs[51]="Ihh";
		reactantIDs[52]="Lef/Tcf";
		reactantIDs[53]="Lef/Tcf PTM";
		reactantIDs[55]="Lef/Tcf prot";
		reactantIDs[56]="MEF2C";
		reactantIDs[57]="MEF2C PTM";
		reactantIDs[58]="MEF2C prot";
		reactantIDs[59]="MMP13";
		reactantIDs[60]="Msx2";
		reactantIDs[61]="Msx2 PTM";
		reactantIDs[63]="Msx2 prot";
		reactantIDs[64]="NFkb";
		reactantIDs[65]="Nkx3.2";
		reactantIDs[66]="PI3K";
		reactantIDs[67]="PI3K PTM";
		reactantIDs[68]="PI3K prot";
		reactantIDs[69]="PKA";
		reactantIDs[70]="PP2A";
		reactantIDs[71]="PPR";
		reactantIDs[72]="PPR PTM";
		reactantIDs[73]="PPR prot";
		reactantIDs[74]="PTHrP";
		reactantIDs[75]="R-smad";
		reactantIDs[76]="Ras";
		reactantIDs[77]="Runx2";
		reactantIDs[78]="Runx2 PTM";
		reactantIDs[79]="Runx2 prot";
		reactantIDs[80]="STAT1";
		reactantIDs[81]="Smad3";
		reactantIDs[82]="Smad7";
		reactantIDs[83]="Smadcomplex";
		reactantIDs[84]="Sox9";
		reactantIDs[85]="Sox9 PTM";
		reactantIDs[86]="Sox9 prot";
		reactantIDs[87]="TGFb";
		reactantIDs[88]="Wnt";
		reactantIDs[89]="dEF-1";
		reactantIDs[90]="destruction complex";
		reactantIDs[91]="p38";
	}
	
	//Parse the UPPAAL verifyta output trace to get the (time, value) pairs for all reactants
	public void analize(String fileName) throws Exception {
		FileInputStream fi = new FileInputStream(fileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(fi));
		String line;
		Pattern simPointPattern = Pattern.compile("\\([-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?\\,[0-9]*\\)");
		while ((line = br.readLine()) != null && !line.startsWith(" -- Property is satisfied."));
		boolean stableState = true; //We call a final state "stable" where no reactant changed by more than 5/100 during the last 10 minutes of the simulation
		while ((line = br.readLine()) != null) {
			int reactantId = Integer.parseInt(line.substring(1, line.indexOf(":")));
			line = br.readLine();
			if (reactantIDs[reactantId] == null) continue; //Some existing reactants were removed from my reactantIDs because they were dummy nodes used to describe reactions (thus not real reactants)
			line = line.substring(line.indexOf(":"));
			Matcher pointMatcher = simPointPattern.matcher(line);
			double lastTime,
				   lastValue,
				   time,
				   value,
				   minVal,
				   maxVal;
			Vector<String> points = new Vector<String>();
			while (pointMatcher.find()) {
				String p = pointMatcher.group();
				p = p.substring(1, p.length() - 1);
				points.add(p);
			}
			int nPunti = points.size();
			int k = nPunti - 1;
			String p = points.elementAt(k);
			lastTime = Double.valueOf(p.substring(0, p.indexOf(",")).trim());
			lastValue = Double.valueOf(p.substring(p.indexOf(",") + 1).trim());
			lastValues[reactantId] = (int)Math.round(lastValue);
			minVal = maxVal = lastValue;
			k--;
			while (k > 0) {
				String point = points.elementAt(k);
				time = Double.valueOf(point.substring(0, point.indexOf(",")).trim());
				value = Double.valueOf(point.substring(point.indexOf(",") + 1).trim());
				if (minVal > value) {
					minVal = value;
				}
				if (maxVal < value) {
					maxVal = value;
				}
				if (lastTime - time > LAST_MINUTES) {
					break;
				}
				k--;
			}
			if (maxVal - minVal > 5) {
				stableState = false;
			}
		}
		if (stableState) {
			System.out.print("TRUE, ");
		} else {
			System.out.print("FALSE, ");
		}
		for (int i = 0; i < lastValues.length - 1; i++) {
			if (reactantIDs[i] != null) {
				System.out.print(lastValues[i] + ", ");
			}
		}
		if (reactantIDs[lastValues.length - 1] != null) {
			System.out.print(lastValues[lastValues.length - 1]);
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		AnalyzeResult a = new AnalyzeResult();
		try {
			if (args.length > 0 && new File(args[0]).exists()) {
				a.analize(args[0]);
			} else {
				a.analize("./Dummy_result.txt");
			}
		} catch (Exception ex) {
			ex.printStackTrace(System.err);
			System.out.println("ERROR");
		}
	}
}
