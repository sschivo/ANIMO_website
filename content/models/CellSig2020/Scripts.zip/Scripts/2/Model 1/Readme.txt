Experiment 1a - 1 million simulations starting from random activity for all nodes, compute the % of final states that are Sox9-positive, Runx2-positive or Null (the only possible final states).

Instructions
- Copy the contents of this directory to the server from which the experiments will be queued. These scripts are made to run with SLURM: if your cluster is managed in other ways, please adapt the scripts before executing them.
- Ensure that the parameters are correctly set:
  - in run_experiment.sh, check that the number of cores corresponds to the actual number of cores in your cluster:
    in case changes are needed, update the corresponding part in run_step.sh
  - in run_step.sh, insert the correct path to the UPPAAL "verifyta" executable
- Run the experiment with the command "sbatch run_experiment.sh"
- After the experiment has finished, the directory will be populated with many files starting with "_ANIMO*": they contain the stdout/stderr of the executed processes and are useful in case of bug-hunting.
- All the *.csv files contain the results of the simulations and can be put into one single file with the command "cat ANIMO_output*.csv > Results.csv" (the header contained in the file ANIMO_output.csv should end up being the first line of Results.csv: please check that it is so).
- Execute the analysis script by calling "find_all_numbers.sh": you should get the resulting percentages of the three final states.
