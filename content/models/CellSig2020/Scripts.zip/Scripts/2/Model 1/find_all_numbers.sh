#!/bin/bash
#Find all percentages for the final states Sox9, Runx2 and Null, including 0.99 confidence intervals and quantity of unstable states
cat Results.csv | awk -F ", " 'NR==1{
	nStable = 0;
	nNULL = 0;
	nSox9 = 0;
	nRunx2 = 0;
	costante95 = 3.8416;
	costante99 = 6.6564;
}{
	if ($83 ~/TRUE/) {
		nStable = nStable + 1;
		if ($151 < 20 && $158 < 20) {
			nNULL = nNULL + 1;
		} else if ($151 > 65 && $158 < 20) {
			nRunx2 = nRunx2 + 1;
		} else if ($151 < 20 && $158 > 65) {
			nSox9 = nSox9 + 1;
		}
	}
}END{
	if (nStable == 0) {
		printf "0 Stable!";
	} else {
		printf "%d Stable, of which\n", nStable;
		printf "%d Sox9\n", nSox9;
		printf "%d Runx2\n", nRunx2;
		printf "%d NULL\n\n", nNULL;
		percSox9 = 1.0 * nSox9 / nStable;
		confSox9 = sqrt(costante99 * percSox9 * (1 - percSox9) / nStable) * 100;
		percSox9 = percSox9 * 100;
		printf "Sox9 = %f +/- %f (0.99 conf)\n", percSox9, confSox9;
		percRunx2 = 1.0 * nRunx2 / nStable;
		confRunx2 = sqrt(costante99 * percRunx2 * (1 - percRunx2) / nStable) * 100;
		percRunx2 = percRunx2 * 100;
		printf "Runx2 = %f +/- %f (0.99 conf)\n", percRunx2, confRunx2;
		percNULL = 1.0 * nNULL / nStable;
		confNULL = sqrt(costante99 * percNULL * (1 - percNULL) / nStable) * 100;
		percNULL = percNULL * 100;
		printf "NULL = %f +/- %f (0.99 conf)\n", percNULL, confNULL;
	}
}'
